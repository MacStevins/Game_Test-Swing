package macstevins.game.test2.core.io;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

public class FileUtil {

	public static void deleteDir(File file) {
		
		File[] conts = file.listFiles();
		if(conts != null) for(File f : conts) if(!Files.isSymbolicLink(f.toPath())) deleteDir(f);
		file.delete();
	
	}

	public static void extractZip(File src, File dest, String... folder) throws ZipException, IOException { extractZip(src, dest, false, folder); }

	public static void extractZip(File src, File dest, boolean inverse, String... folder) throws ZipException, IOException {
		
		try(ZipFile zp = new ZipFile(src)) {
			
			Enumeration<?> ents = zp.entries();
			
			while(ents.hasMoreElements()) {
				
				ZipEntry zpEnt = (ZipEntry) ents.nextElement();
				ArrayList<String> fld = new ArrayList<>(Arrays.asList(folder));
				
				if(fld.stream().anyMatch(s -> zpEnt.getName().indexOf(s) == 0) == inverse) continue;
				
				File cpFile = new File(dest, zpEnt.getName());
				
				if(!cpFile.exists()) {
					
					cpFile.getParentFile().mkdirs();
					cpFile = new File(dest, zpEnt.getName());
				
				}
				if(zpEnt.isDirectory()) continue;
				
				try(InputStream is = zp.getInputStream(zpEnt); FileOutputStream fos = new FileOutputStream(cpFile)) { while(is.available() > 0) fos.write(is.read()); }
			
			}
		
		}
		System.gc();
	
	}

}
