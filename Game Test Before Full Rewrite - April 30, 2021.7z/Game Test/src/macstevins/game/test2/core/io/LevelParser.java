package macstevins.game.test2.core.io;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import macstevins.game.test2.core.window.Game;
import macstevins.game.test2.core.world.World;

public class LevelParser {

	private static File lvlDir = AssetLoader.getFolderFromTmp("levels");

	public static World loadLevel(Game game, String level) throws IOException { return loadLevel(game, level, AssetLoader.getPackDir()); }

	public static World loadLevel(Game game, String level, String directory) throws IOException {
		
		File lvlFile = new File(lvlDir.getAbsolutePath() + File.separatorChar + directory + File.separatorChar + level + ".lvl");
		World wrld = new World(game);
		
		if(!lvlFile.exists() || lvlFile.isDirectory()) throw new FileNotFoundException("Level given does not exist or is not a file: " + lvlFile);
		
		try(BufferedReader br = new BufferedReader(new FileReader(lvlFile))) {
			
			String line;
			while((line = br.readLine()) != null) {
				
				switch(line.substring(0, line.indexOf("="))) {
					
					case "windowBorder": {
						
						wrld.createWindowBarrier();
						break;
					
					}
				
				}
			
			}
		
		}
		
		return wrld;
	
	}

}
