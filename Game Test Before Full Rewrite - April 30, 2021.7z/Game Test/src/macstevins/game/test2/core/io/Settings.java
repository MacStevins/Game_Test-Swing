package macstevins.game.test2.core.io;

public class Settings {

	/** Controls */
	public static int upKey = 87, lfKey = 65, dnKey = 83, rtKey = 68;
//	public static int upKey = 38, lfKey = 37, dnKey = 40, rtKey = 39;

	/** Framerate */
	public static int fps = 60;

}
