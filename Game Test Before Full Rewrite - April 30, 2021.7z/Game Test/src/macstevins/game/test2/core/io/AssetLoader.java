package macstevins.game.test2.core.io;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class AssetLoader {

	private static AssetLoader inst;
	private static String packDir;
	private static Path astDir;
	private static Path tmpDir;

	private AssetLoader(String packPath) {
			
		try {
			
			packDir = packPath.replace('.', File.separatorChar);
			File runDir = new File(getClass().getProtectionDomain().getCodeSource().getLocation().toURI().getPath());
			
			if(runDir.isDirectory()) tmpDir = runDir.toPath();
			else {
				
				FileUtil.extractZip(runDir, (tmpDir = Files.createTempDirectory(packPath + ".asset.")).toFile(), true, "META-INF", packDir);
				Runtime.getRuntime().addShutdownHook(new Thread() { @Override public synchronized void start() { FileUtil.deleteDir(tmpDir.toFile()); } });
			
			}
			
			astDir = Paths.get(tmpDir.toString(), "assets", packDir);
		
		}
		catch(Exception e) { e.printStackTrace(); }
	
	}

	public static AssetLoader createInstance(String packPath) { return (inst == null) ? inst = new AssetLoader(packPath) : inst; }

	public static File getAsset(String type, String name) {
		
		for(File f : astDir.toFile().listFiles()) if(f.getName().equals(type)) for(File fa : f.listFiles()) if(fa.getName().equals(name)) return fa;
		
		return null;
	
	}

	public static File getFolderFromTmp(String name) {
		
		for(File f : tmpDir.toFile().listFiles()) if(f.getName().equals(name)) return f;
		
		return null;
	
	}

	public static File getTempDir() { return tmpDir.toFile(); }

	public static String getPackDir() { return packDir; }

}
