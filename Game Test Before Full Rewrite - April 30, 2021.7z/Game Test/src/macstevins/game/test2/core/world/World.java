package macstevins.game.test2.core.world;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.util.ArrayList;
import java.util.Collection;

import macstevins.game.test2.core.io.KeyHandler;
import macstevins.game.test2.core.window.Game;
import macstevins.game.test2.core.window.Layer;

public class World extends Layer {

	private Game win;

	private static final long serialVersionUID = 2688216244151563748L;

	protected ArrayList<Object> objs = new ArrayList<>();
	protected Dimension winSize;
	protected Player plr;

	public World(Game win) { this.win = win; }

	public World addObject(Object obj) {
		
		objs.add(obj);
		return this;
	
	}

	public World addObject(Object[] objs) {
		
		for(int a = 0; a < objs.length; a++) this.objs.add(objs[0]);
		return this;
	
	}

	public World addObject(Collection<? extends Object> objs) {
		
		this.objs.addAll(objs);
		return this;
	
	}

	public World addPlayer(Player plr) {
		
		this.plr = plr;
		plr.kh = (KeyHandler) win.getKeyListeners()[0];
		plr.wrld = this;
		return this;
	
	}

	public World createWindowBarrier() {
		
		winSize = win.getPanelSize();
		win.addComponentListener(new ComponentAdapter() {
		
			@Override
			public void componentResized(ComponentEvent e) {
				
				super.componentResized(e);
				
				new Thread(new Runnable() {
				
					@Override
					public void run() {
						
						winSize = win.getPanelSize();
						setBounds(0, 0, winSize.width, winSize.height);
						if(plr.rect.getMaxX() > winSize.width) plr.rect.x = winSize.width - plr.rect.width;
						if(plr.rect.getMaxY() > winSize.height) plr.rect.y = winSize.height - plr.rect.height;
						
						for(int a = 0; a < objs.size(); a++) {
							
							if(objs.get(a).name.equals("winBorTop") || objs.get(a).name.equals("winBorBtm")) {
								
								objs.get(a).rect.width = winSize.width;
								if(objs.get(a).name.equals("winBorBtm")) objs.get(a).rect.y = winSize.height;
								continue;
							
							}
							if(objs.get(a).name.equals("winBorLft") || objs.get(a).name.equals("winBorRht")) {
								
								objs.get(a).rect.height = winSize.height;
								if(objs.get(a).name.equals("winBorRht")) objs.get(a).rect.x = winSize.width;
								continue;
							
							}
						
						}
					
					}
				
				}).start();
			
			}
		
		});
		
		objs.add(new Object(new Color(0, 0, 0, 0), new Dimension(winSize.width, 1), new Point(0, -1), "winBorTop"));
		objs.add(new Object(new Color(0, 0, 0, 0), new Dimension(1, winSize.height), new Point(-1, 0), "winBorLft"));
		objs.add(new Object(new Color(0, 0, 0, 0), new Dimension(winSize.width, 1), new Point(-1, winSize.height), "winBorBtm"));
		objs.add(new Object(new Color(0, 0, 0, 0), new Dimension(1, winSize.height), new Point(winSize.width, -1), "winBorRht"));
		
		return this;
	
	}

	public Object getObject(int index) { return objs.get(index); }

	public Player getPlayer() { return plr; }

	public void init() { setBounds(0, 0, win.getPanelSize().width, win.getPanelSize().height); }

	public void update() {
		
		plr.update();
		for(int a = 0; a < objs.size(); a++) objs.get(a).update();
	
	}

	@Override
	public void paintComponent(Graphics g) {
		
		super.paintComponent(g);
		
		if(objs == null || plr == null) return;
		
		for(Object obj : objs) {
			
			g.setColor(obj.clr);
			g.fillRect(obj.rect.x, obj.rect.y, obj.rect.width, obj.rect.height);
		
		}
		
		g.setColor(plr.clr);
		g.fillRect(plr.rect.x, plr.rect.y, plr.rect.width, plr.rect.height);
		win.setTitle("x: " + plr.rect.x + ", y: " + plr.rect.y);
	
	}

}
