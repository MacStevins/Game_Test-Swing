package macstevins.game.test2.core.world;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;

import macstevins.game.test2.core.io.KeyHandler;

import static macstevins.game.test2.core.io.Settings.*;

public class Player extends Object {

	protected KeyHandler kh;
	protected World wrld;
	protected int speed, tick;

	public Player(Dimension size, Point initPos, int speed) { this(Color.gray, size, initPos, speed); }

	public Player(Color clr, Dimension size, Point initPos, int speed) {
		
		super(clr, size, initPos, "plr");
		this.speed = speed;
	
	}

	private void collisDetect(int side) {
		
		for(int a = 0; a < wrld.objs.size(); a++) {
			
			Object obj = wrld.objs.get(a);
			if(rect.getMaxY() < obj.rect.y + 1 || rect.y > obj.rect.getMaxY() - 1 || rect.x > obj.rect.getMaxX() - 1 || rect.getMaxX() < obj.rect.x + 1) continue;
			
			if(side == 1 && rect.getMaxY() > obj.rect.y + 1) {
				
				rect.y++;
				continue;
			
			}
			if(side == 2 && rect.getMaxX() > obj.rect.x + 1) {
				
				rect.x++;
				continue;
			
			}
			if(side == 3 && rect.y < obj.rect.getMaxY() - 1) {
				
				rect.y--;
				continue;
			
			}
			if(side == 4 && rect.x < obj.rect.getMaxX() - 1) {
				
				rect.x--;
				continue;
			
			}
		
		}
	
	}

	@Override
	public void update() {
		
		tick++;
		if(tick >= speed) {
			
			tick = 0;
			prevPos = rect.getLocation();
			
			if(kh.isKeyPressed(upKey)) rect.y -= 1;
			collisDetect(1);
			if(kh.isKeyPressed(lfKey)) rect.x -= 1;
			collisDetect(2);
			if(kh.isKeyPressed(dnKey)) rect.y += 1;
			collisDetect(3);
			if(kh.isKeyPressed(rtKey)) rect.x += 1;
			collisDetect(4);
		
		}
	
	}

}
