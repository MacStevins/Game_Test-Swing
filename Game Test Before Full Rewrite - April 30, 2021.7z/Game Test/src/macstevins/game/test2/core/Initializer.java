package macstevins.game.test2.core;

import javax.swing.SwingUtilities;

import macstevins.game.test2.core.io.AssetLoader;
import macstevins.game.test2.core.window.Window;

public class Initializer {

	public Initializer(Window win, String packPath) {
		
		AssetLoader.createInstance(packPath);
		
//		SwingUtilities.invokeLater(new ExceptionWindow(win));
		if(true) SwingUtilities.invokeLater(win);
	
	}

}
