package macstevins.game.test2;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;

import macstevins.game.test2.core.window.Game;
import macstevins.game.test2.core.world.Object;
import macstevins.game.test2.core.world.Player;

public class TheGame extends Game {

	private static final long serialVersionUID = -789872385081646887L;

	@Override
	public void init() {
		
		setSize(new Dimension(500, 500));
		drawFps();
		
		wrld.createWindowBarrier().addPlayer(new Player(Color.gray, new Dimension(25, 25), new Point((getContentPane().getPreferredSize().width / 2) - (25 / 2), (getContentPane().getPreferredSize().height / 2) - (25 / 2)), 35));
		
		Point[] objLoc      = new Point[]     {new Point(150, 300),    new Point(213, 188),   new Point(263, 188),   new Point(50, 100),    new Point(98, 53),     new Point(350, 200),   new Point(350, 250),   new Point(200, 450)};
		Dimension[] objSize = new Dimension[] {new Dimension(50, 100), new Dimension(25, 25), new Dimension(25, 25), new Dimension(100, 5), new Dimension(5, 100), new Dimension(25, 25), new Dimension(25, 25), new Dimension(100, 10)};
		
		for(int a = 0; a < (objLoc.length | objSize.length); a++) wrld.addObject(new Object(Color.black, objSize[a], objLoc[a]));
		
		super.init();
	
	}

	@Override public void run() { init(); }

}
