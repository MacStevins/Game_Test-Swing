package macstevins.game.test1.core.io;

public class Settings {

	//Controls
	public static int upKey = 87, lfKey = 65, dnKey = 83, rtKey = 68;

	//Framerate
	public static int fps = 60;

}
