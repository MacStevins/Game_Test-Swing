package macstevins.game.test2.core.window;

import java.awt.Dimension;

import javax.swing.JFrame;

import macstevins.game.test2.core.io.KeyHandler;

public class Window extends JFrame implements Runnable {

	private static final long serialVersionUID = 1355341064471498304L;

	private KeyHandler kh = new KeyHandler(this);

	public Window() {
		
		setSize(new Dimension(100, 100));
		setLayout(null);
		setDefaultCloseOperation(3);
		addKeyListener(kh);
	
	}

	public void init() { init(true); }

	public void init(boolean visibility) {
		
		setLocationRelativeTo(null);
		setVisible(visibility);
	
	}

	public Dimension getPanelSize() { return new Dimension(getWidth(), getHeight() - 37); }

	@Override public void run() { throw new IllegalStateException("Window has not initialized, please contact the developer."); }

	@Override
	public void setSize(Dimension size) {
		
		getContentPane().setPreferredSize(size);
		pack();
	
	}

	@Override public void setSize(int width, int height) { setSize(new Dimension(width, height)); }

}
