package macstevins.game.test2.core.io;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;

public class KeyHandler extends KeyAdapter {

	private static boolean[] keys = new boolean[65536];

	static { for(int a = 0; a < keys.length; a++) keys[a] = false; }

	public KeyHandler(JFrame win) { win.addWindowFocusListener(new WindowHandler()); }

	@Override public void keyPressed(KeyEvent e) { keys[e.getKeyCode()] = true; }

	@Override public void keyReleased(KeyEvent e) { keys[e.getKeyCode()] = false; }

	public boolean isKeyPressed(int key) { return keys[key]; }

	public static class WindowHandler extends WindowAdapter {
	
		public static boolean hasLostFocus = false;
	
		@Override public void windowGainedFocus(WindowEvent e) { hasLostFocus = false; }
	
		@Override
		public void windowLostFocus(WindowEvent e) {
			
			hasLostFocus = true;
			for(int a = 0; a < keys.length; a++) keys[a] = false;
		
		}
	
	}

}
