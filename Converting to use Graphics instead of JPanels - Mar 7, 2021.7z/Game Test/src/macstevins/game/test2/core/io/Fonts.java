package macstevins.game.test2.core.io;

import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.io.File;
import java.util.ArrayList;

public class Fonts {

	private static ArrayList<Font> fonts = new ArrayList<>();

	public static Font createFont(int type, File path) throws Exception {
		
		Font font = Font.createFont(type, path).deriveFont(Font.PLAIN, 12);
		GraphicsEnvironment.getLocalGraphicsEnvironment().registerFont(font);
		fonts.add(font);
		return font;
	
	}

	public static Font getFont(String name) {
		
		for(int a = 0; a < fonts.size(); a++) if(fonts.get(a).getName().equals(name)) return fonts.get(a);
		return null;
	
	}

}
