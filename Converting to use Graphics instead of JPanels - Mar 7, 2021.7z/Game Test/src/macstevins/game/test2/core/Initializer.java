package macstevins.game.test2.core;

import javax.swing.SwingUtilities;

import macstevins.game.test2.core.window.ExceptionWindow;
import macstevins.game.test2.core.window.Window;

public class Initializer {

	public Initializer(Window win) {
		
		SwingUtilities.invokeLater(new ExceptionWindow(win));
		
		if(true) SwingUtilities.invokeLater(win);
	
	}

}
