package macstevins.game.test2.lwjgl.core.window;

import static org.lwjgl.glfw.Callbacks.*;
import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.system.MemoryUtil.*;

import java.io.*;

import org.lwjgl.glfw.*;
import org.lwjgl.opengl.*;

import macstevins.game.test2.lwjgl.core.*;
import macstevins.game.test2.lwjgl.core.system.*;
import macstevins.game.test2.lwjgl.core.util.*;

/**
 * 
 * @author MacStevins
 */
public class GLFWWindow implements Closeable {

	static {
		
		GLFWErrorCallback.createPrint(System.err).set();
		
		if(!glfwInit()) throw new IllegalStateException("Unable to initialize GLFW");
	
	}

	/**
	 * Title property of the GLFW Window
	 */
	private String title;

	private Updater updater;

	/**
	 * FPS Counter
	 */
	private float bTime, dt = 0, eTime = bTime = (float) glfwGetTime();

	/**
	 * RGBA Values of the clear color
	 */
	private float r, g, b, a;

	/**
	 * Width and Height property of the GLFW Window
	 */
	private int height, width;

	/**
	 * The GLFW Window itself
	 */
	private long glfwWindow = NULL;

	private static GLFWWindow win;

	/**
	 * 
	 * @param title
	 * @param width
	 * @param height
	 */
	private GLFWWindow(String title, int width, int height) {
		
		glfwDefaultWindowHints();
		glfwWindowHint(GLFW_VISIBLE, GLFW_FALSE);
		
		if((glfwWindow = glfwCreateWindow(this.width = width, this.height = height, this.title = title, NULL, NULL)) == NULL) throw new IllegalStateException("Failed to create a GLFW Window");
		
		glfwMakeContextCurrent(glfwWindow);
		glfwSwapInterval(1);
		
		GL.createCapabilities();
		GLUtil.setupDebugMessageCallback(System.err);
		
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	
	}

	/**
	 * Creates a GLFW Window with a set window title of {@code "GLFW Window"} and window size of {@code "854x480"} 
	 * 
	 * @return The Created GLFW Window
	 */
	public static GLFWWindow createWindow() { return createWindow("GLFW Window", 854, 480); }

	/**
	 * Creates a GLFW Window with a given window title and a set window size of {@code "854x480"} 
	 * 
	 * @param title - The title of the GLFW Window
	 * 
	 * @return The Created GLFW Window
	 */
	public static GLFWWindow createWindow(String title) { return createWindow(title, 854, 480); }

	/**
	 * Creates a GLFW Window with a given window title and window size
	 * 
	 * @param title - The title of the GLFW Window
	 * @param width - The width of the GLFW Window
	 * @param height - The height of the GLFW Window
	 * 
	 * @return The Created GLFW Window
	 */
	public static GLFWWindow createWindow(String title, int width, int height) {
		
		if(win == null) win = new GLFWWindow(title, width, height);
		
		return win;
	
	}

	/**
	 * Creates a GLFW Window with a given window title and a window size based on a given percentage from the monitor 
	 * 
	 * @param title - The title of the GLFW Window
	 * @param percent - 
	 * @param monitorIndex - the index of the monitor array, the array can be seen on the graphics/display settings, {@code 0} is the main monitor
	 * 
	 * @return The Created GLFW Window
	 */
	public static GLFWWindow createWindow(String title, float percent, int monitorIndex) {
		
		Monitor mon = Monitor.getMonitorDetail(Monitor.getMonitor(monitorIndex));
		
		return createWindow(title, Math.round(mon.width() * percent), Math.round(mon.height() * percent));
	
	}

	/**
	 * Creates a GLFW Window with a set window title of {@code "GLFW Window"} and a window size based on a given percentage from the monitor 
	 * 
	 * @param percent - 
	 * @param monitorIndex - the index of the monitor array, the array can be seen on the graphics/display settings, {@code 0} is the main monitor
	 * 
	 * @return The Created GLFW Window
	 */
	public static GLFWWindow createWindow(float percent, int monitorIndex) { return createWindow("GLFW Window", percent, monitorIndex); }

	/**
	 * Creates a GLFW Window with a set window title of {@code "GLFW Window"} and a given window size
	 * 
	 * @param width - The width of the GLFW Window
	 * @param height - The height of the GLFW Window
	 * 
	 * @return The Created GLFW Window
	 */
	public static GLFWWindow createWindow(int width, int height) { return createWindow("GLFW Window", width, height); }

	public static GLFWWindow get() { return win; }

	public boolean isFullscreen() { return glfwGetWindowMonitor(glfwWindow) != NULL; }

	public int getHeight() { return height; }

	public int getWidth() { return width; }

	/**
	 * Positions the window's center to the center of the specified monitor
	 * 
	 * @param monitorIndex - the index of the monitor array, the array can be seen on the graphics/display settings, {@code 0} is the main monitor
	 */
	public void centerWindow(int monitorIndex) { centerWindow(Monitor.getMonitor(monitorIndex)); }

	/**
	 * Positions the window's center to the center of the specified monitor<br><br>
	 * 
	 * Use {@link #centerWindow(int)} for indexces instead of the pointer to the monitor array buffer index
	 * 
	 * @param monitor - the pointer to the monitor array buffer index
	 */
	public void centerWindow(long monitor) {
		
		Monitor mon = Monitor.getMonitorDetail(monitor);
		
		glfwSetWindowPos(glfwWindow, (mon.monitorPosX() + (mon.width() - width) / 2), (mon.monitorPosY() + (mon.height() - height) / 2));
	
	}

	/**
	 * Makes the GLFW Window fullscreen to a specified monitor<br>
	 * Setting {@code monitorIndex} parameter to {@code -1} will unset it's fullscreen property<br><br>
	 * 
	 * The default windowed position is setted by {@link #centerWindow(int)}
	 * 
	 * @param monitorIndex - the index of the monitor array, the array can be seen on the graphics/display settings, {@code 0} is the main monitor
	 */
	public void fullscreenWindow(int monitorIndex) { fullscreenWindow((monitorIndex > -1) ? Monitor.getMonitor(monitorIndex) : -1); }

	/**
	 * Makes the GLFW Window fullscreen to a specified monitor<br>
	 * Setting {@code monitorIndex} parameter to {@code -1} will unset it's fullscreen property<br><br>
	 * 
	 * The default windowed position is setted by {@link #centerWindow(int)}<br><br>
	 * 
	 * Use {@link #fullscreenWindow(int)} for indexces instead of the pointer to the monitor array buffer index
	 * 
	 * @param monitor - the pointer to the monitor array buffer index
	 */
	public void fullscreenWindow(long monitor) {
		
		if(monitor == -1) {
			
			glfwSetWindowMonitor(glfwWindow, NULL, 0, 0, width, height, GLFW_DONT_CARE);
			centerWindow(0);
		
		}
		else {
			
			Monitor mon = Monitor.getMonitorDetail(monitor);
			
			glfwSetWindowMonitor(glfwWindow, monitor, mon.monitorPosX(), mon.monitorPosY(), mon.width(), mon.height(), mon.refreshRate());
		
		}
	
	}

	/**
	 * Maximizes the window to the current display location of the window
	 */
	public void maximizeWindow() { glfwMaximizeWindow(glfwWindow); }

	/**
	 * Shows the window and starts the game loxp
	 */
	public void run() {
		
		System.gc();
		
		glfwShowWindow(glfwWindow);
		initLoops();
	
	}

	/**
	 * Changes the clear color of the OpenGL Buffer in it's RGB values. See {@code glClearColor} for more information<br/>
	 * <br/>
	 * Uses the previous set Alpha value
	 * 
	 * @param r The value of the red channel to clear the buffer
	 * @param g The value of the green channel to clear the buffer
	 * @param b The value of the blue channel to clear the buffer
	 */
	public void setClearColori(int r, int g, int b) { setClearColorf(r / 255f, g / 255f, b / 255f, a); }

	/**
	 * Changes the clear color of the OpenGL Buffer in it's RGBA values. See {@code glClearColor} for more information 
	 * 
	 * @param r The value of the red channel to clear the buffer
	 * @param g The value of the green channel to clear the buffer
	 * @param b The value of the blue channel to clear the buffer
	 * @param a The value of the alpha channel to clear the buffer
	 */
	public void setClearColori(int r, int g, int b, int a) { setClearColorf(r / 255f, g / 255f, b / 255f, a / 255f); }

	/**
	 * Changes the clear color of the OpenGL Buffer in it's RGB values. See {@code glClearColor} for more information<br/>
	 * <br/>
	 * Uses the previous set Alpha value
	 * 
	 * @param r The value of the red channel to clear the buffer
	 * @param g The value of the green channel to clear the buffer
	 * @param b The value of the blue channel to clear the buffer
	 */
	public void setClearColorf(float r, float g, float b) { setClearColorf(r, g, b, a); }

	/**
	 * Changes the clear color of the OpenGL Buffer in it's RGBA values. See {@code glClearColor} for more information
	 * 
	 * @param r The value of the red channel to clear the buffer
	 * @param g The value of the green channel to clear the buffer
	 * @param b The value of the blue channel to clear the buffer
	 * @param a The value of the alpha channel to clear the buffer
	 */
	public void setClearColorf(float r, float g, float b, float a) {
		
		this.r = r;
		this.g = g;
		this.b = b;
		this.a = a;
	
	}

	public void setUpdater(Updater updater) {
		
		updater.init();
		this.updater = updater;
	
	}

	/**
	 * Sets an attribute to the window. See {@link GLFW#glfwSetWindowAttrib} for more information
	 * 
	 * @param attrib The attribute name from GLFW
	 * @param value The value to set to the attribute
	 */
	public void setWindowAttribute(int attrib, int value) { glfwSetWindowAttrib(glfwWindow, attrib, value); }

	/**
	 * Destorys the window and it's context, and frees memory
	 */
	public void stop() {
		
		glfwFreeCallbacks(glfwWindow);
		glfwDestroyWindow(glfwWindow);
			
		glfwTerminate();
		glfwSetErrorCallback(null).free();
	
	}

	/**
	 * 
	 */
	private void initLoops() {
		
		while(!glfwWindowShouldClose(glfwWindow)) {
			
			glfwPollEvents();
			
			glClearColor(r, g, b, a);
			glClear(GL_COLOR_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
			
			if(Instances.getCurrentLevel() != null) Instances.getCurrentLevel().update();
			else if(updater != null) updater.update();
			
			glfwSwapBuffers(glfwWindow);
			
			eTime = (float) glfwGetTime();
			dt = eTime - bTime;
			bTime = eTime;
		
		}
	
	}

	@Override public void close() throws IOException { stop(); }

}
