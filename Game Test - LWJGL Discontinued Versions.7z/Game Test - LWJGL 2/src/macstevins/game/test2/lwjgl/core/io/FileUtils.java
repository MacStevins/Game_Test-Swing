package macstevins.game.test2.lwjgl.core.io;

import java.io.*;

public class FileUtils {

	public static String getSimpleExtension(File file) { return getSimpleExtension(file.getName(), false); }

	public static String getSimpleExtension(File file, boolean xDot) { return getSimpleExtension(file.getName(), xDot); }

	public static String getSimpleExtension(String fileName) { return getSimpleExtension(fileName, false); }

	public static String getSimpleExtension(String fileName, boolean xDot) { return fileName.substring(fileName.lastIndexOf('.') + ((xDot) ? 1 : 0)); }

}
