package macstevins.game.test2.lwjgl.core;

import java.util.*;

import macstevins.game.test2.lwjgl.core.level.*;
import macstevins.game.test2.lwjgl.core.renderer.*;

public class Instances {

	private static Camera2D camera;

	private static Level currentLvl;

	private static List<Level> prevLvls = new ArrayList<>();

	private static Shader shad;

	public static void setCamera2D(Camera2D camera) { Instances.camera = camera; }

	/**
	 * Sets the specified level to be displayed and runned while the previous one will be set to a list
	 * 
	 * @param lvl The new level to be played
	 */
	public static void setCurrentLevel(Level lvl) {
		
		if(currentLvl != null) prevLvls.add(prevLvls.size(), currentLvl);
		
		Collections.rotate(prevLvls, 1);
		
		currentLvl = lvl;
		currentLvl.init();
	
	}

	public static void setShader(Shader shad) { Instances.shad = shad; }

	public static Camera2D getCamera2D() {
		
		Camera2D camera = Instances.camera;
		
		return camera;
	
	}

	public static Level getCurrentLevel() {
		
		Level currentLvl = Instances.currentLvl;
		
		return currentLvl;
	
	}

	public static Shader getShader() {
		
		Shader shad = Instances.shad;
		
		return shad;
	
	}

}
