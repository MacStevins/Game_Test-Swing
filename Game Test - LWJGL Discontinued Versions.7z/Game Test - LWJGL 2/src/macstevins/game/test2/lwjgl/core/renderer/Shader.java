package macstevins.game.test2.lwjgl.core.renderer;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL13.*;
import static org.lwjgl.opengl.GL20.*;

import java.io.*;
import java.nio.*;
import java.nio.file.*;

import org.joml.*;
import org.json.simple.*;
import org.json.simple.parser.*;
import org.lwjgl.*;

import macstevins.game.test2.lwjgl.core.io.*;

public class Shader {

	private String filePath, fragFile, fragSrc, vertFile, vertSrc;
	private boolean isCompiled, isUsed;
	private int fragID, shadProg, vertID;

	public Shader(String filePath) {
		
		try {
			
			Path path = Paths.get(this.filePath = filePath);
			 
			if(!Files.isDirectory(path)) {
				
				setupSingleFileGLSL(new String(Files.readAllBytes(path)));
				return;
			
			}
			
			for(File file : path.toFile().listFiles()) {
				
				switch(FileUtils.getSimpleExtension(file, true).toLowerCase()) {
					
					case "json": 
						setupJSONFile(file, path);
						break;
					
				}
			
			}
		
		}
		catch(IOException | ParseException e) {
			
			e.printStackTrace();
			System.exit(-1);
		
		}
	
	}

	public void compileAndLink() { 
		
		try {
			
			if(isCompiled) return;
			
			glShaderSource(vertID = glCreateShader(GL_VERTEX_SHADER), vertSrc);
			glCompileShader(vertID);
			
			if(glGetShaderi(vertID, GL_COMPILE_STATUS) == GL_FALSE) throw new GLSLException("File: '" + ((vertFile != null) ? vertFile : filePath) + "' had an error | Vertex Shader Compilation Failed.\n\n" + glGetShaderInfoLog(vertID, glGetShaderi(vertID, GL_INFO_LOG_LENGTH)) + "\nThis can be found:");
			
			glShaderSource(fragID = glCreateShader(GL_FRAGMENT_SHADER), fragSrc);
			glCompileShader(fragID);
			
			if(glGetShaderi(fragID, GL_COMPILE_STATUS) == GL_FALSE) throw new GLSLException("File: '" + ((fragFile != null) ? fragFile : filePath) + "' had an error | Fragment Shader Compilation Failed.\n\n" + glGetShaderInfoLog(fragID, glGetShaderi(fragID, GL_INFO_LOG_LENGTH)) + "\nThis can be found:");
			
			glAttachShader(shadProg = glCreateProgram(), vertID);
			glAttachShader(shadProg, fragID);
			glLinkProgram(shadProg);
			
			if(glGetProgrami(shadProg, GL_LINK_STATUS) == GL_FALSE) throw new GLSLException("File: '" + filePath + "' had an error | Linking Shader Failed.");
			
			isCompiled = true;
		
		}
		catch(Exception e) {
			
			e.printStackTrace();
			System.exit(-1);
		
		}
	
	}

	public void detach() {
		
		glUseProgram(0);
		isUsed = false;
	
	}

	public void uploadTextureToSlot(int slot) {
		
		use();
		glUniform1i(glGetUniformLocation(shadProg, "TEX_FROM_SLOT"), slot);
		glActiveTexture(GL_TEXTURE0 + slot);
	
	}

	public void uploadValue(String varName, Object val) {
		
		use();
		switch(val.getClass().getSimpleName()) {
			
			case "Float": glUniform1f(glGetUniformLocation(shadProg, varName), (float) val); break;
			case "Integer": glUniform1i(glGetUniformLocation(shadProg, varName), (int) val); break;
			case "Matrix3f": {
				
				FloatBuffer matBuf = BufferUtils.createFloatBuffer(9);
				glUniformMatrix3fv(glGetUniformLocation(shadProg, varName), false, ((Matrix3f) val).get(matBuf));
				break;
			
			}
			case "Matrix4f": {
				
				FloatBuffer matBuf = BufferUtils.createFloatBuffer(16);
				glUniformMatrix4fv(glGetUniformLocation(shadProg, varName), false, ((Matrix4f) val).get(matBuf));
				break;
			
			}
			case "Vector2f": glUniform2f(glGetUniformLocation(shadProg, varName), ((Vector2f) val).x, ((Vector2f) val).y); break;
			case "Vector3f": glUniform3f(glGetUniformLocation(shadProg, varName), ((Vector3f) val).x, ((Vector3f) val).y, ((Vector3f) val).z); break;
			case "Vector4f": glUniform4f(glGetUniformLocation(shadProg, varName), ((Vector4f) val).x, ((Vector4f) val).y, ((Vector4f) val).z, ((Vector4f) val).w); break;
		
		}
	
	}

	public void use() {
		
		if(isUsed) return;
		
		glUseProgram(shadProg);
		isUsed = true;
	
	}

	private void setupSingleFileGLSL(String source) throws IOException {
		
		String splSrc[] = source.split("(#type)( )+([a-zA-Z]+)"), shadType[] = new String[splSrc.length - 1];
		int sol, eol = 0;
		
		for(int a = 1; a < splSrc.length; a++) {
			
			sol = source.indexOf("#type", eol) + 6;
			eol = source.indexOf(System.lineSeparator(), sol);
			shadType[a - 1] = source.substring(sol, eol).trim();
			
			if(shadType[a - 1].equals("fragment")) fragSrc = splSrc[a];
			else if(shadType[a - 1].equals("vertex")) vertSrc = splSrc[a];
			else throw new IOException("Invalid shader type/s");
		
		}
	
	}

	private void setupJSONFile(File file, Path path) throws ParseException, IOException {
		
		JSONObject json = (JSONObject) new JSONParser().parse(new String(Files.readAllBytes(file.toPath())));
		JSONArray fileArr = (JSONArray) json.get("files");
		
		for(int a = 0; a < fileArr.size(); a++) {
			
			switch(FileUtils.getSimpleExtension((String) fileArr.get(a), true).toLowerCase()) {
				
				case "fsh": {
					
					fragSrc = new String(Files.readAllBytes(Paths.get((fragFile = path + System.getProperty("file.separator") + (String) fileArr.get(a)))));
					break;
				
				}
				case "vsh": {
					
					vertSrc = new String(Files.readAllBytes(Paths.get((vertFile = path + System.getProperty("file.separator") + (String) fileArr.get(a)))));
					break;
				
				}
			
			}
		
		}
	
	}

	private class GLSLException extends IllegalStateException {
	
		private static final long serialVersionUID = 7162961940921853237L;

		public GLSLException(String message) { super(message); }
	
	} 

}
