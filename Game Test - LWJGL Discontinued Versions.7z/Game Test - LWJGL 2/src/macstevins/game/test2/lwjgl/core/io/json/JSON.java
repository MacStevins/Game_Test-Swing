package macstevins.game.test2.lwjgl.core.io.json;

import java.io.*;
import java.nio.file.*;

@Deprecated
public class JSON {

	public JSON(File file) throws IOException {
		
		String fileCont = new String(Files.readAllBytes(file.toPath()));
		
		parse(fileCont);
	
	}

	private void parse(String source) {
		
		
	
	}

	class JSONObject {
	
		
	
	}

}
