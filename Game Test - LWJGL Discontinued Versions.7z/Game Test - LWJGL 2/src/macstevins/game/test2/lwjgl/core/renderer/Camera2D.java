package macstevins.game.test2.lwjgl.core.renderer;

import org.joml.*;

import macstevins.game.test2.lwjgl.core.window.*;

public class Camera2D {

	private Matrix4f projMat;
	private Vector2f camPos;

	public Camera2D() { this(new Vector2f()); }

	public Camera2D(Vector2f pos) {
		
		this.camPos = pos;
		this.projMat = new Matrix4f();
		adjustProj();
	
	}

	public Matrix4f getProjectionMatrix() { return projMat; }

	public Matrix4f getViewMatrix() { return new Matrix4f().setLookAt(new Vector3f(camPos.x, camPos.y, 0f), new Vector3f(camPos.x, camPos.y, -1f), new Vector3f(0f, 1f, 0f)); }

	public void adjustProj() { projMat.setOrtho(0f, ((float) GLFWWindow.get().getHeight()), 0f, ((float) GLFWWindow.get().getWidth()), 0f, 1f); }

}
