package macstevins.game.test2.lwjgl.core.system;

import static org.lwjgl.glfw.GLFW.*;

import java.awt.*;
import java.nio.*;

import org.lwjgl.*;
import org.lwjgl.glfw.*;

/**
 * A container class that holds a monitor's data
 * 
 * @author MacStevins
 */
public class Monitor {

	private GLFWVidMode.Buffer MODES;
	private String MONITOR_NAME;
	private int REFRESH_RATE,
				HEIGHT,
				MONITOR_POS_X,
				MONITOR_POS_Y,
				WIDTH;

	private static Monitor instance;

	@Deprecated
	public GLFWVidMode.Buffer modes() { return MODES; }

	public Dimension resolution() { return new Dimension(WIDTH, HEIGHT); }
 
	public Point position() { return new Point(MONITOR_POS_X, MONITOR_POS_Y); }

	public String monitorName() { return MONITOR_NAME; }

	public int refreshRate() { return REFRESH_RATE; }

	public int height() { return HEIGHT; }

	public int monitorPosX() { return MONITOR_POS_X; }

	public int monitorPosY() { return MONITOR_POS_Y; }

	public int width() { return WIDTH; }

	/**
	 * Deprecated because don't know if it works
	 */
	@Deprecated
	public static Monitor getMonitorDetail(GLFWVidMode mode) {
		
		Monitor mon = new Monitor();
		
		mon.MONITOR_NAME = get().MONITOR_NAME;
		mon.REFRESH_RATE = mode.refreshRate();
		mon.HEIGHT = mode.height();
		mon.MONITOR_POS_X = get().MONITOR_POS_X;
		mon.MONITOR_POS_Y = get().MONITOR_POS_Y;
		mon.WIDTH = mode.width();
		
		return mon;
	
	}

	/**
	 * 
	 * 
	 * Use {@link #getMonitor(int)} for indexces instead of the pointer to the monitor array buffer index
	 * 
	 * @param monitor - the pointer to the monitor array buffer index
	 * 
	 * @return The monitor details
	 */
	public static Monitor getMonitorDetail(long monitor) {
		
		GLFWVidMode mode = glfwGetVideoMode(monitor);
		IntBuffer monX = BufferUtils.createIntBuffer(1), monY = BufferUtils.createIntBuffer(1);
		Monitor mon = get();
		
		glfwGetMonitorPos(monitor, monX, monY);
		
		mon.MODES = glfwGetVideoModes(monitor);
		mon.MONITOR_NAME = glfwGetMonitorName(monitor);
		mon.REFRESH_RATE = mode.refreshRate();
		mon.HEIGHT = mode.height();
		mon.MONITOR_POS_X = monX.get(0);
		mon.MONITOR_POS_Y = monY.get(0);
		mon.WIDTH = mode.width();
		
		return mon;
	
	}

	/**
	 * 
	 * 
	 * @param index - the index of the monitor array, the array can be seen on the graphics/display settings, {@code 0} is the main monitor
	 * 
	 * @return - the pointer to the monitor array buffer index
	 */
	public static long getMonitor(int index) { return glfwGetMonitors().get(index); }

	private static Monitor get() {
		
		if(instance == null) instance = new Monitor();
		return instance;
	
	}

}
