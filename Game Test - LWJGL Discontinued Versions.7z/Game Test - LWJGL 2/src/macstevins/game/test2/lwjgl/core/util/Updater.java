package macstevins.game.test2.lwjgl.core.util;

public abstract class Updater {

	public void init() {}

	public abstract void update();

}
