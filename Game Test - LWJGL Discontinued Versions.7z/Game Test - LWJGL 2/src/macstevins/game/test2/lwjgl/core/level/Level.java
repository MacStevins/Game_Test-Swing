package macstevins.game.test2.lwjgl.core.level;

import macstevins.game.test2.lwjgl.core.*;
import macstevins.game.test2.lwjgl.core.renderer.*;
import macstevins.game.test2.lwjgl.core.util.*;
import macstevins.game.test2.lwjgl.core.window.*;

public abstract class Level extends Updater {

	protected Camera2D cam;
	protected GLFWWindow win = GLFWWindow.get();

	@Override
	public abstract void init();

	public void initCam(Camera2D cam) {
		
		if(this.cam != null) return;
		
		this.cam = cam;
		Instances.setCamera2D(cam);
	
	}

	public void initShader(Shader shad) {
		
		shad.compileAndLink();
		Instances.setShader(shad);
	
	}

}
