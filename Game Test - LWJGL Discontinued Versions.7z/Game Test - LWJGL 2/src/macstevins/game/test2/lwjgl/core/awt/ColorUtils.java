package macstevins.game.test2.lwjgl.core.awt;

public class ColorUtils {

	public static float[] hexToRGBAf(String hex) {
		
		float[] colors = new float[4];
		int[] tmpCol = hexToRGBAi(hex);
		
		for(int a = 0; a < colors.length; a++) colors[a] = tmpCol[a] / 255f;
		
		return colors;
	
	}

	public static int[] hexToRGBAi(String hex) {
		
		int[] colors = new int[4];
		hex.replace('#', ' ');
		
		switch(hex.length()) {
			
			case 3: {
				
				for(int a = 0; a < hex.length(); a++) colors[a] = Integer.parseInt(hex.substring(a, a + 1), 16) * 255 / 15;
				colors[3] = 255;
				break;
			
			}
			case 6: case 8: {
				
				for(int a = 0; a < hex.length(); a += 2) colors[a / 2] = Integer.parseInt(hex.substring(a, a + 2), 16);
				break;
			
			}
		
		}
		
		return colors;
	
	}

}
