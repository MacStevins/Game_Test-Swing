package macstevins.game.test2.lwjgl.level;

import macstevins.game.test2.lwjgl.core.level.*;
import macstevins.game.test2.lwjgl.core.renderer.*;

public class DefaultLevel extends Level {

	@Override
	public void init() {
		
		initCam(new Camera2D());
		initShader(new Shader("./assets/shaders/default1/default.glsl"));
		
		win.setClearColori(238, 238, 238);
	
	}

	@Override
	public void update() {
		
//		cam.adjustProj();
	
	}

}
