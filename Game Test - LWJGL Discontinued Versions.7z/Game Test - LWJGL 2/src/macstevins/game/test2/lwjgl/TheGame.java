package macstevins.game.test2.lwjgl;

import macstevins.game.test2.lwjgl.core.*;
import macstevins.game.test2.lwjgl.core.window.*;
import macstevins.game.test2.lwjgl.level.*;

public class TheGame {

	public TheGame() {
		
		GLFWWindow win = GLFWWindow.createWindow(500, 500);
		
		win.centerWindow(0);
		win.setClearColori(0, 0, 0);
		
		Instances.setCurrentLevel(new DefaultLevel());
		
		win.run();
		
		win.stop();
	
	}

}
