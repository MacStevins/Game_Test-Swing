package macstevins.game.test1.lwjgl;

import macstevins.game.test1.lwjgl.core.level.*;
import macstevins.game.test1.lwjgl.core.window.*;

public class TheGame {

	public TheGame() {
		
		GLFWWindow win = GLFWWindow.createWindow("Game Test", 500, 500);
		
		win.centerWindow(0);
		win.setCurrentLevel(new DefaultLevel());
		win.run();
		
		win.stop();
	
	}

}
