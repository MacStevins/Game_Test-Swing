package macstevins.game.test1.lwjgl;

public class Main { public static void main(String[] args) { new TheGame(); } }
