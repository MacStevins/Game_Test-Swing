package macstevins.game.test1.lwjgl.core.level;

import java.util.*;

import macstevins.game.test1.lwjgl.core.level.object.type.*;
import macstevins.game.test1.lwjgl.core.rendering.*;
import macstevins.game.test1.lwjgl.core.window.*;

public abstract class Level {

	private List<GameObject> objs = new ArrayList<GameObject>();

	protected Camera cam;
	protected GLFWWindow win = GLFWWindow.get();
//	protected ObjectCollectionMesh mesh = new ObjectCollectionMesh();
	protected Shader shader;

	public abstract void init();

	public <T extends GameObject> T getObject(Class<T> obj) {
		
		for(GameObject a : objs) {
			
			try { if(obj.isAssignableFrom(a.getClass())) return obj.cast(a); }
			catch(ClassCastException e) {
				
				e.printStackTrace();
				System.exit(-1);
			
			}
		
		}
		return null;
	
	}

	public Camera getCamera() { return cam; }

	public <T extends GameObject> void removeObject(Class<T> obj) {
		
		for(int a = 0; a < objs.size(); a++) {
			
			if(obj.isAssignableFrom(objs.get(a).getClass())) {
				
				objs.remove(a);
				return;
			
			}
		
		}
	
	}

	public void addObject(GameObject obj) {
		
		objs.add(obj);
//		mesh.addObjectToMesh(obj);
		
		obj.init();
	
	}

	public void start() {
		
//		mesh.setShader(shader);
//		for(GameObject obj : objs) {
//			
//			Class<?>[] comps = obj.getClass().getInterfaces();
//			for(int a = 0; a < comps.length; a++) if(comps[a].getClass().isInstance(Component.class)) ((Component) obj).start();
//		
//		}
	
	}

	public void update(float dt) {
		
		for(GameObject obj : objs) {
			
			obj.update(dt);
//			Class<?>[] comps = obj.getClass().getInterfaces();
//			for(int a = 0; a < comps.length; a++) if(comps[a].getClass().isInstance(Component.class)) ((Component) obj).update();
		
		}
	
	}

}
