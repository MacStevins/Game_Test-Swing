package macstevins.game.test1.lwjgl.core.level.object.type.primitive;

import macstevins.game.test1.lwjgl.core.level.object.type.*;

public class SquareObject extends GameObject {

	public SquareObject() {
		
		
	
	}

	@Override
	public void init() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(float dt) {
		// TODO Auto-generated method stub
		
	}

}
