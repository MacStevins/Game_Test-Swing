package macstevins.game.test1.lwjgl.core.rendering;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL13.*;
import static org.lwjgl.opengl.GL20.*;

import java.io.*;
import java.nio.*;
import java.nio.file.*;

import org.joml.*;
import org.lwjgl.*;

public class Shader {

	private String filePath, fragSrc, vertSrc;
	private boolean isCompiled, isUsed;
	private int fragID, shadProg, vertID;

	public Shader(String filePath) {
		
		try {
			
			this.filePath = filePath;
			
			if(filePath.lastIndexOf(".glsl") != (filePath.length() - 5)) throw new IOException("File \"" + filePath + "\" is a invalid shader file.");
			
			String source = new String(Files.readAllBytes(Paths.get(filePath))), splSrc[] = source.split("(#type)( )+([a-zA-Z]+)"), shadType[] = new String[splSrc.length - 1];
			int sol, eol = 0;
			
			for(int a = 1; a < splSrc.length; a++) {
				
				sol = source.indexOf("#type", eol) + 6;
				eol = source.indexOf("\r\n", sol);
				shadType[a - 1] = source.substring(sol, eol).trim();
				
				if(shadType[a - 1].equals("fragment")) fragSrc = splSrc[a];
				else if(shadType[a - 1].equals("vertex")) vertSrc = splSrc[a];
				else throw new IOException("Invalid shader type/s");
			
			}
		
		}
		catch(IOException e) {
			
			e.printStackTrace();
			System.exit(-1);
		
		}
	
	}

	public void compileAndLink() {
		
		try {
			
			if(!isCompiled) {
				
				glShaderSource(vertID = glCreateShader(GL_VERTEX_SHADER), vertSrc);
				glCompileShader(vertID);
				
				if(glGetShaderi(vertID, GL_COMPILE_STATUS) == GL_FALSE) throw new Exception("ERROR: '" + filePath + "' | Vertex Shader Compilation Failed.\n\n" + glGetShaderInfoLog(vertID, glGetShaderi(vertID, GL_INFO_LOG_LENGTH)) + "\nThis can be found:");
				
				glShaderSource(fragID = glCreateShader(GL_FRAGMENT_SHADER), fragSrc);
				glCompileShader(fragID);
				
				if(glGetShaderi(fragID, GL_COMPILE_STATUS) == GL_FALSE) throw new Exception("ERROR: '" + filePath + "' | Fragment Shader Compilation Failed.\n\n" + glGetShaderInfoLog(fragID, glGetShaderi(fragID, GL_INFO_LOG_LENGTH)) + "\nThis can be found:");
				
				glAttachShader(shadProg = glCreateProgram(), vertID);
				glAttachShader(shadProg, fragID);
				glLinkProgram(shadProg);
				
				if(glGetProgrami(shadProg, GL_LINK_STATUS) == GL_FALSE) throw new Exception("ERROR: '" + filePath + "' | Linking Shader Failed.\n\n" + glGetProgramInfoLog(shadProg, glGetProgrami(shadProg, GL_INFO_LOG_LENGTH)) + "\nThis can be found:");
				
				isCompiled = true;
			
			}
		
		}
		catch(Exception e) {
			
			e.printStackTrace();
			System.exit(-1);
		
		}
	
	}

	public void detach() {
		
		glUseProgram(0);
		isUsed = false;
	
	}

	public void uploadTextureToSlot(int slot) {
		
		use();
		glUniform1i(glGetUniformLocation(shadProg, "TEX_FROM_SLOT"), slot);
		glActiveTexture(GL_TEXTURE0 + slot);
	
	}

	public void uploadValue(String varName, Object val) {
		
		use();
		switch(val.getClass().getSimpleName()) {
			
			case "Float": glUniform1f(glGetUniformLocation(shadProg, varName), (float) val); break;
			case "Integer": glUniform1i(glGetUniformLocation(shadProg, varName), (int) val); break;
			case "Matrix3f": {
				
				FloatBuffer matBuf = BufferUtils.createFloatBuffer(9);
				glUniformMatrix3fv(glGetUniformLocation(shadProg, varName), false, ((Matrix3f) val).get(matBuf));
				break;
			
			}
			case "Matrix4f": {
				
				FloatBuffer matBuf = BufferUtils.createFloatBuffer(16);
				glUniformMatrix4fv(glGetUniformLocation(shadProg, varName), false, ((Matrix4f) val).get(matBuf));
				break;
			
			}
			case "Vector2f": glUniform2f(glGetUniformLocation(shadProg, varName), ((Vector2f) val).x, ((Vector2f) val).y); break;
			case "Vector3f": glUniform3f(glGetUniformLocation(shadProg, varName), ((Vector3f) val).x, ((Vector3f) val).y, ((Vector3f) val).z); break;
			case "Vector4f": glUniform4f(glGetUniformLocation(shadProg, varName), ((Vector4f) val).x, ((Vector4f) val).y, ((Vector4f) val).z, ((Vector4f) val).w); break;
		
		}
	
	}

	public void use() {
		
		if(!isUsed) {
			
			glUseProgram(shadProg);
			isUsed = true;
		
		}
	
	}

}
