package macstevins.game.test1.lwjgl.core;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.system.MemoryUtil.*;

public class Values {

	/** OpenGL Original Values */
	public static final int GL_VENDOR			= 0x1F00,
							GL_RENDERER			= 0x1F01,
							GL_VERSION			= 0x1F02,
							GL_EXTENSIONS		= 0x1F03;

	/** GLFW Version */
	public static final int GLFW_FULL_VERSION	= 0x1F04;

	/** GPU Values */
	public final static int GL_GPU_NAME			= 0x1F10,
							GL_GPU_VERSION		= 0x1F11,
							OPENGL_VERSION		= 0x1F12;

	/** System Values */
	public final static int OS_NAME				= 0x1F20,
							JAVA_VERSION		= 0x1F21;

	/** System Values */
	public final static int EMPTY_TEXTURE		= 0x1F30;

//	private final static int LAST_VALUE			= 0x1FFF;

	public static String getStringFromGL(int key) { return (glfwGetCurrentContext() == NULL) ? "" : glGetString(key); }

	public static Object getValue(int key) {
		
		switch(key) {
			
			case GL_VENDOR: case GL_RENDERER: case GL_VERSION: case GL_EXTENSIONS: return getStringFromGL(key);
			
			
			case GLFW_FULL_VERSION: return GLFW_VERSION_MAJOR + "." + GLFW_VERSION_MINOR + "." + GLFW_VERSION_REVISION;
			
			
			case GL_GPU_NAME: return trySplitAndGet(getStringFromGL(GL_RENDERER), '/', 0);
			
			case GL_GPU_VERSION: return trySplitAndGet(getStringFromGL(GL_VERSION), ' ', 2);
			
			case OPENGL_VERSION: return trySplitAndGet(getStringFromGL(GL_VERSION), ' ', 0);
			
			
			case JAVA_VERSION: return System.getProperty("java.version");
			
			case OS_NAME: return System.getProperty("os.name");
			
			
			case EMPTY_TEXTURE: {
				
				return null;
			
			}
		
		}
		
		return null;
	
	}

	public static float[] hexToRGBAf(String hex) {
		
		float[] colors = new float[4];
		int[] tmpCol = hexToRGBAi(hex);
		
		for(int a = 0; a < colors.length; a++) colors[a] = tmpCol[a] / 255f;
		
		return colors;
	
	}

	public static int[] hexToRGBAi(String hex) {
		
		int[] colors = new int[4];
		hex.replace('#', ' ');
		
		switch(hex.length()) {
			
			case 3: {
				
				for(int a = 0; a < hex.length(); a++) colors[a] = Integer.parseInt(hex.substring(a, a + 1), 16) * 255 / 15;
				colors[3] = 255;
				break;
			
			}
			case 6: case 8: {
				
				for(int a = 0; a < hex.length(); a += 2) colors[a / 2] = Integer.parseInt(hex.substring(a, a + 2), 16);
				break;
			
			}
		
		}
		
		return colors;
	
	}

	private static String trySplitAndGet(String value, char regex, int index) { return trySplitAndGet(value, regex, index); }

	@SuppressWarnings("unused")
	private static String trySplitAndGet(String value, String regex, int index) {
		
		String[] splStr = value.split(regex);
		
		return (splStr.length < 2) ? value : splStr[index];
	
	}

}
