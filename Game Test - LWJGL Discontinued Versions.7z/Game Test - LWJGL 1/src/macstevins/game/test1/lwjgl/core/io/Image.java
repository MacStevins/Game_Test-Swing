package macstevins.game.test1.lwjgl.core.io;

import static org.lwjgl.stb.STBImage.*;

import java.io.*;
import java.nio.*;

import org.lwjgl.glfw.*;
import org.lwjgl.system.*;

public class Image implements AutoCloseable {

	public final ByteBuffer IMAGE;
//	public final GLFWImage GLFW_IMAGE;
	public final GLFWImage.Buffer GLFW_IMAGE;

	public final int COLOR_CHANNELS,
					 HEIGHT,
					 WIDTH;

	public Image(String filePath) throws IOException {
		
		if(!FileUtils.checkFileExtension(filePath, "png")) throw new IOException("File '" + filePath + "' is not a png");
 		try(MemoryStack ms = MemoryStack.stackPush(); GLFWImage glfwImage = GLFWImage.create()) {
			
			stbi_set_flip_vertically_on_load(true);
			
			IntBuffer channels = ms.callocInt(1), height = ms.callocInt(1), width = ms.callocInt(1);
			
			IMAGE = stbi_load(filePath, width, height, channels, 0);
			COLOR_CHANNELS = channels.get(0);
			HEIGHT = height.get(0);
			WIDTH = width.get(0);
			
			if(IMAGE == null || IMAGE.capacity() < 1) throw new IOException("Image '" + filePath + "' does not exist");
			if(COLOR_CHANNELS < 3 && COLOR_CHANNELS > 4) throw new IOException("Image '" + filePath + "' has invalid color channels");
			
			GLFW_IMAGE = GLFWImage.create(1);
			glfwImage.set(WIDTH, HEIGHT, IMAGE);
			GLFW_IMAGE.put(glfwImage);
		
		}
	
	}

	@Override public void close() throws IOException { stbi_image_free(IMAGE); }

}
