package macstevins.game.test1.lwjgl.core.rendering;

import static org.lwjgl.opengl.GL11.*;

import java.io.*;

import macstevins.game.test1.lwjgl.core.io.*;

public class Texture {

//	private String filePath;
	private int texID;

	public Texture(String filePath) {
		
		try(Image image = new Image(filePath)) {
			
//			this.filePath = filePath;
			
			glBindTexture(GL_TEXTURE_2D, texID = glGenTextures());
			
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
			
			glTexImage2D(GL_TEXTURE_2D, 0, (image.COLOR_CHANNELS == 3) ? GL_RGB : (image.COLOR_CHANNELS == 4) ? GL_RGBA : 0, image.WIDTH, image.HEIGHT, 0, (image.COLOR_CHANNELS == 3) ? GL_RGB : (image.COLOR_CHANNELS == 4) ? GL_RGBA : 0, GL_UNSIGNED_BYTE, image.IMAGE);
		
		}
		catch(IOException e) {
			
			e.printStackTrace();
			
//			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, 0, 0, 0, GL_RGB, GL_UNSIGNED_BYTE, ByteBuffer.allocate(0));
		
		}
	
	}

	public void bind() { glBindTexture(GL_TEXTURE_2D, texID); }

	public void unbind() { glBindTexture(GL_TEXTURE_2D, 0); }

}
