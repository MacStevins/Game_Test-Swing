package macstevins.game.test1.lwjgl.core.rendering.meshtemp;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL15.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL30.*;

import java.lang.reflect.*;
import java.nio.*;

import macstevins.game.test1.lwjgl.core.rendering.*;
import macstevins.game.test1.lwjgl.core.window.*;

public class MeshRenderer<T1, T2> {

	/**
	 * Sets offsets and sizes of the positions of a vertex for the array
	 */
	private   int POS_OFF       = 0;
	protected int POS_SIZE      = 2;

	/**
	 * Sets offsets and sizes of the colors of a vertex for the array
	 */
	private   int COL_OFF       = POS_OFF + POS_SIZE * Float.BYTES;
	protected int COL_SIZE      = 3;

	/**
	 * Sets sizes and its bytes alternate of the array
	 */
	protected int VERT_SIZE       = POS_SIZE + COL_SIZE,
				  VERT_SIZE_BYTES = VERT_SIZE * Float.BYTES;

	protected FloatBuffer vertArr;
	protected Shader shader;
	protected int vaoID, vboID;

	public MeshRenderer() {
		
		Type type = getClass().getGenericSuperclass();
		if(type instanceof ParameterizedType) {
			
			Type[] types = ((ParameterizedType) type).getActualTypeArguments();
			
			for(int a = 0; a < types.length; a++) {
				
				String[] tClsSpl = types[a].getTypeName().split("\\.");
				String typeCls = tClsSpl[tClsSpl.length - 1].toLowerCase();
				
				System.out.println(types[a].getTypeName());
				
				if(tClsSpl.length == 1 && typeCls.matches("(t)\\d|(t)")) break;
				
				if(a == 0) {
					
					if(typeCls.contains("vector2")) POS_SIZE = 2;
					else if(typeCls.contains("vector3")) POS_SIZE = 3;
					else throw new RuntimeException("Type \"" + typeCls + "\" is invalid");
				
				}
				else if(a == 1) {
					
					if(typeCls.contains("float") || typeCls.contains("vector3")) COL_SIZE = 3;
					else if(typeCls.contains("vector4")) COL_SIZE = 4;
					else throw new RuntimeException("Type \"" + typeCls + "\" is invalid");
				
				}
			
			}
			
			resetValues();
		
		}
	
	}

	@SuppressWarnings("unchecked")
	public void addVerticies(T1... verts) { 
		
		
	
	}

	public void render() {
		
		glBindBuffer(GL_ARRAY_BUFFER, vboID);
		glBufferSubData(GL_ARRAY_BUFFER, 0, vertArr);
		
		shader.uploadValue("uProjMat", GLFWWindow.get().getCurrentLevel().getCamera().getProjectionMatrix());
		shader.uploadValue("uViewMat", GLFWWindow.get().getCurrentLevel().getCamera().getViewMatrix());
		shader.uploadValue("uTime", (float) glfwGetTime());
		
		glDrawElements(GL_TRIANGLES, vertArr.capacity(), GL_UNSIGNED_INT, 0);

		glBindVertexArray(vaoID);
	
	}

	public void setShader(Shader shader) {
		
		shader.compileAndLink();
		shader.use();
		this.shader = shader;
	
	}

	protected void init(int[] elemArr) {
		
		glBindVertexArray(vaoID = glGenVertexArrays());
		glBindBuffer(GL_ARRAY_BUFFER, vboID = glGenBuffers());
		glBufferData(GL_ARRAY_BUFFER, vertArr.capacity() * Float.BYTES, GL_DYNAMIC_DRAW);
		
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, glGenBuffers());
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, elemArr, GL_STATIC_DRAW);
		
		glVertexAttribPointer(0, POS_SIZE, GL_FLOAT, false, VERT_SIZE_BYTES, POS_OFF);
		glEnableVertexAttribArray(0);
		
		glVertexAttribPointer(1, COL_SIZE, GL_FLOAT, false, VERT_SIZE_BYTES, COL_OFF);
		glEnableVertexAttribArray(1);
	
	}

	protected void resetValues() {
		
		COL_OFF = POS_OFF + POS_SIZE * Float.BYTES;
		VERT_SIZE = POS_SIZE + COL_SIZE;
		VERT_SIZE_BYTES = VERT_SIZE * Float.BYTES;
	
	}

}
