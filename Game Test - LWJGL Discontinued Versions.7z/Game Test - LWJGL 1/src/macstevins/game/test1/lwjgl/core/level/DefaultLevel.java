package macstevins.game.test1.lwjgl.core.level;

import macstevins.game.test1.lwjgl.core.level.object.type.*;
import macstevins.game.test1.lwjgl.core.rendering.*;

public class DefaultLevel extends Level {

	@Override
	public void init() {
		
		cam = new Camera();
//		addObject(new Player());
		addObject(new GameObject() {
		
			@Override
			public void init() {
				
				
			
			}
		
			@Override
			public void update(float dt) {}
		
		});
		
		(shader = new Shader("./assets/shaders/default.glsl")).compileAndLink();
		win.setClearColor(238, 238, 238);
	
	}

	@Override
	public void update(float dt) {
		
		super.update(dt);
//		mesh.render();
	
	}

}
