package macstevins.game.test1.lwjgl.core.level.object.component;

public interface Component {

	public void start();

	public void update();

}
