package macstevins.game.test1.lwjgl.core.rendering.mesh;

import java.util.*;

import macstevins.game.test1.lwjgl.core.level.object.type.*;
import macstevins.game.test1.lwjgl.core.level.object.type.primitive.*;

@SuppressWarnings("all")
public class SquareObjectCollectionMesh extends MeshRenderer {

	protected int isFull, objLimit;

	private List<SquareObject> objs = new ArrayList<>();

	public SquareObjectCollectionMesh(int objLimit, int colors) {
		
		if(objLimit < 1 && objLimit > 1024) objLimit = 1024;
		this.objLimit = objLimit;
	
	}

	public void addObjectToMesh(SquareObject obj) {
		
		objs.add(obj);
	
	}

}
