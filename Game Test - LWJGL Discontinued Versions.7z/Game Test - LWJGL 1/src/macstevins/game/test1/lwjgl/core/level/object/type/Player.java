package macstevins.game.test1.lwjgl.core.level.object.type;

import static org.lwjgl.glfw.GLFW.*;

import macstevins.game.test1.lwjgl.core.io.*;

public class Player extends GameObject {

	public Player() {}

//	public Player(Vector2f pos, Vector2f size, Vector3f col) { this(pos, size, new Vector4f(col, 1)); }
//
//	public Player(Vector2f pos, Vector2f size, Vector4f col) {
//		
//		this.position = pos;
//		this.size = size;
//	
//	}
//
//	public Vector2f getCenter() { return new Vector2f(position.x + (size.x / 2), position.y + (size.y / 2)); }

	@Override
	public void init() {
		
//		setKey(GLFW_KEY_W, UP);
	
	}

	@Override
	public void update(float dt) {
		
		if(KeyListener.isKeyPressed(GLFW_KEY_W)) position.y++;
		if(KeyListener.isKeyPressed(GLFW_KEY_A)) position.x--;
		if(KeyListener.isKeyPressed(GLFW_KEY_S)) position.y--;
		if(KeyListener.isKeyPressed(GLFW_KEY_D)) position.x++;
	
	}

}
