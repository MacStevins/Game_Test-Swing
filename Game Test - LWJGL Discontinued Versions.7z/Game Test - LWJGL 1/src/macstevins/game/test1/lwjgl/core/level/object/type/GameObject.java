package macstevins.game.test1.lwjgl.core.level.object.type;

import org.joml.*;

import macstevins.game.test1.lwjgl.core.level.*;
import macstevins.game.test1.lwjgl.core.window.*;

public abstract class GameObject {

	protected Level lvl = GLFWWindow.get().getCurrentLevel();
	protected Vector2f position;
	protected Vector4f color;

	private Vector2f verts[];
	private int[] elemArr;

	public abstract void init();

	public abstract void update(float dt);

	public Vector2f getPosition() { return position; }

	public Vector2f[] getVerts() {
		
		Vector2f[] vertsOut = verts;
		return vertsOut;
	
	}

	public Vector4f getColor() { return color; }

	public int[] getElements() {
		
		if(elemArr == null) {
			
			elemArr = new int[verts.length];
			for(int a = 0; a < verts.length; a++) elemArr[a] = a;
		
		}
		
		return elemArr;
	
	}

}
