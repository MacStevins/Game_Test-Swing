package macstevins.game.test1.lwjgl.core.nio;

import java.nio.*;

public class BufferUtils {

	public static FloatBuffer resizeFloatBuffer(FloatBuffer buffer) { return resizeFloatBuffer(buffer, buffer.position()); }

	public static FloatBuffer resizeFloatBuffer(FloatBuffer buffer, int endIndex) {
		
		FloatBuffer fb = FloatBuffer.allocate(endIndex);
		
		for(int a = 0; a < fb.limit(); a++) fb.put(buffer.get(a));
		fb.rewind();
		
		return fb;
	
	}

}
