package macstevins.game.test1.lwjgl.core.rendering.mesh;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL15.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL30.*;

import java.nio.*;
import java.util.*;

import org.joml.*;
import org.lwjgl.system.*;

import macstevins.game.test1.lwjgl.core.rendering.*;
import macstevins.game.test1.lwjgl.core.window.*;

@SuppressWarnings("all")
public class MeshRenderer {

	/**
	 * Sets offsets and sizes of the positions of a vertex for the array
	 */
	private   int POS_OFF			   = 0;
	protected int POS_SIZE			   = 2;

	/**
	 * Sets offsets and sizes of the colors of a vertex for the array
	 */
	private   int COL_OFF			   = POS_OFF + POS_SIZE * Float.BYTES;
	protected int COL_SIZE			   = 3;

	/**
	 * Sets sizes and its bytes alternate of the array
	 */
	protected int VERT_SIZE			   = POS_SIZE + COL_SIZE,
				  VERT_SIZE_BYTES	   = VERT_SIZE * Float.BYTES;

	protected int VERT_ARR_CAPACITY	   = 1024;

	private List<FloatBuffer> vertArrs = new ArrayList<>();
	private List<Integer> vaoIDs	   = new ArrayList<>(),
						  vboIDs	   = new ArrayList<>();
	private Shader shader;
	private boolean isStarted;

	/**
	 * Adds verticies to the rendering array
	 * 
	 * Depending on the size of the position vectors, some value would be dropped and some would be added to a default value of 0
	 * 
	 * Note: The colors are defaulted to black
	 * 
	 * @param verts
	 * @param cols
	 */
	public void addDataObject(Object[] verts, Object[] cols) {
		
		String vertType = verts.getClass().getSimpleName().replace("[]", " "),
			   colType  = cols.getClass().getSimpleName().replace("[]", " ");
		FloatBuffer vertArr = FloatBuffer.allocate((verts.length * POS_SIZE) + (cols.length * COL_SIZE));
		
		for(int a = 0; a < verts.length; a++) {
			
			switch(vertType.toLowerCase()) {
				
				case "vector2d": {
					
					vertArr.put((float) ((Vector2d) verts[a]).x);
					vertArr.put((float) ((Vector2d) verts[a]).y);
					if(POS_SIZE == 3) vertArr.put(0);
					break;
				
				}
				case "vector2f": {
					
					vertArr.put(((Vector2f) verts[a]).x);
					vertArr.put(((Vector2f) verts[a]).y);
					if(POS_SIZE == 3) vertArr.put(0);
					break;
				
				}
				case "vector2i": {
					
					vertArr.put(((Vector2i) verts[a]).x);
					vertArr.put(((Vector2i) verts[a]).y);
					if(POS_SIZE == 3) vertArr.put(0);
					break;
				
				}
				case "vector3d": {
					
					vertArr.put((float) ((Vector3d) verts[a]).x);
					vertArr.put((float) ((Vector3d) verts[a]).y);
					if(POS_SIZE == 3) vertArr.put((float) ((Vector3d) verts[a]).z);
					break;
				
				}
				case "vector3f": {
					
					vertArr.put(((Vector3f) verts[a]).x);
					vertArr.put(((Vector3f) verts[a]).y);
					if(POS_SIZE == 3) vertArr.put(((Vector3f) verts[a]).z);
					break;
				
				}
				case "vector3i": {
					
					vertArr.put(((Vector3i) verts[a]).x);
					vertArr.put(((Vector3i) verts[a]).y);
					if(POS_SIZE == 3) vertArr.put(((Vector3i) verts[a]).z);
					break;
				
				}
				default: throw new RuntimeException("Vertex Type: \"" + vertType + "\" is invalid");
			
			}
			
			switch(colType.toLowerCase()) {
				
				case "String": break;
				case "vector3d": {
					
					vertArr.put((float) ((Vector3d) verts[a]).x);
					vertArr.put((float) ((Vector3d) verts[a]).y);
					vertArr.put((float) ((Vector3d) verts[a]).z);
					if(POS_SIZE == 4) vertArr.put(0);
					break;
				
				}
				case "vector3f": {
					
					vertArr.put(((Vector3f) verts[a]).x);
					vertArr.put(((Vector3f) verts[a]).y);
					vertArr.put(((Vector3f) verts[a]).z);
					if(POS_SIZE == 4) vertArr.put(0);
					break;
				
				}
				case "vector3i": {
					
					vertArr.put(((Vector3i) verts[a]).x);
					vertArr.put(((Vector3i) verts[a]).y);
					vertArr.put(((Vector3i) verts[a]).z);
					if(POS_SIZE == 4) vertArr.put(0);
					break;
				
				}
				case "vector4d": {
					
					vertArr.put((float) ((Vector4d) cols[a]).x);
					vertArr.put((float) ((Vector4d) cols[a]).y);
					vertArr.put((float) ((Vector4d) cols[a]).z);
					if(COL_SIZE == 4) vertArr.put((float) ((Vector4d) cols[a]).w);
					break;
				
				}
				case "vector4f": {
					
					vertArr.put(((Vector4f) cols[a]).x);
					vertArr.put(((Vector4f) cols[a]).y);
					vertArr.put(((Vector4f) cols[a]).z);
					if(COL_SIZE == 4) vertArr.put(((Vector4f) cols[a]).w);
					break;
				
				}
				case "vector4i": {
					
					vertArr.put(((Vector4i) cols[a]).x);
					vertArr.put(((Vector4i) cols[a]).y);
					vertArr.put(((Vector4i) cols[a]).z);
					if(COL_SIZE == 4) vertArr.put(((Vector4i) cols[a]).w);
					break;
				
				}
				default: throw new RuntimeException("Color Type: \"" + colType + "\" is invalid");
			
			}
		
		}
		vertArrs.get(vertArrs.size()).put(vertArr.array());
	
	}

	public void create(int[] elemArr) { 
		
		glPolygonMode(GL_FRONT, GL_FILL);
		glBindVertexArray(vaoIDs.set(vaoIDs.size(), glGenVertexArrays()));
		glBindBuffer(GL_ARRAY_BUFFER, vboIDs.set(vboIDs.size(), glGenVertexArrays()));
		glBufferData(GL_ARRAY_BUFFER, vertArrs.set(vertArrs.size(), MemoryUtil.memAllocFloat(VERT_ARR_CAPACITY * VERT_SIZE)).capacity() * Float.BYTES, GL_DYNAMIC_DRAW);
		
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, glGenBuffers());
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, elemArr, GL_STATIC_DRAW);
		
		glVertexAttribPointer(0, POS_SIZE, GL_FLOAT, false, VERT_SIZE_BYTES, POS_OFF);
		glEnableVertexAttribArray(0);
		
		glVertexAttribPointer(1, COL_SIZE, GL_FLOAT, false, VERT_SIZE_BYTES, COL_OFF);
		glEnableVertexAttribArray(1);
	
	}

	public void render() {
		
		for(int a = 0; a < vaoIDs.size(); a++) {
			
			glBindBuffer(GL_ARRAY_BUFFER, vboIDs.get(a));
			glBufferSubData(GL_ARRAY_BUFFER, 0, vertArrs.get(a));
			
			shader.uploadValue("uProjMat", GLFWWindow.get().getCurrentLevel().getCamera().getProjectionMatrix());
			shader.uploadValue("uViewMat", GLFWWindow.get().getCurrentLevel().getCamera().getViewMatrix());
			shader.uploadValue("uTime", (float) glfwGetTime());
			
			glDrawElements(GL_TRIANGLES, vertArrs.get(a).capacity(), GL_UNSIGNED_INT, 0);
			
			glBindVertexArray(vaoIDs.get(a));
		
		}
	
	}

	public void setShader(Shader shader) {
		
		shader.compileAndLink();
		shader.use();
		this.shader = shader;
	
	}

	protected void resetValues() {
		
//		if(isStarted) throw new 
		if(POS_SIZE < 2 || POS_SIZE > 3) throw new RuntimeException("World Coodinate Size: \"" + POS_SIZE + "\" is invalid");
		if(COL_SIZE < 3 || COL_SIZE > 4) throw new RuntimeException("Color Size: \"" + COL_SIZE + "\" is invalid");
		
		COL_OFF = POS_OFF + POS_SIZE * Float.BYTES;
		VERT_SIZE = POS_SIZE + COL_SIZE;
		VERT_SIZE_BYTES = VERT_SIZE * Float.BYTES;
	
	}

}
