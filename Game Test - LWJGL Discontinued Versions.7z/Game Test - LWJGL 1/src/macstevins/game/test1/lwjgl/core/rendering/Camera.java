package macstevins.game.test1.lwjgl.core.rendering;

import org.joml.*;

import macstevins.game.test1.lwjgl.core.window.*;

public class Camera {

	private Matrix4f projMat;
	private Vector2f pos;

	public Camera() { this(new Vector2f()); }

	public Camera(Vector2f pos) {
		
		this.pos = pos;
		this.projMat = new Matrix4f();
		adjustProj();
	
	}

	public Matrix4f getProjectionMatrix() { return projMat; }

	public Matrix4f getViewMatrix() { return new Matrix4f().setLookAt(new Vector3f(pos.x, pos.y, 20f), new Vector3f(pos.x, pos.y, -1f), new Vector3f(0f, 1f, 0f)); }

	public void adjustProj() { projMat.setOrtho(0f, ((float) GLFWWindow.get().WIDTH()), 0f, ((float) GLFWWindow.get().HEIGHT()), 0f, 100f); }

}
