package macstevins.game.test1.lwjgl.core.window;

import static org.lwjgl.glfw.Callbacks.*;
import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.system.MemoryUtil.*;

import java.io.*;
import java.util.*;

import org.lwjgl.glfw.*;
import org.lwjgl.opengl.*;

import macstevins.game.test1.lwjgl.core.io.*;
import macstevins.game.test1.lwjgl.core.level.*;
import macstevins.game.test1.lwjgl.core.system.*;

/**
 * 
 * @author MacStevins
 */
public class GLFWWindow {

	@SuppressWarnings("unused")
	private String title;

	/**
	 * FPS Counter
	 */
	private float bTime, dt = 0, eTime = bTime = (float) glfwGetTime();

	/**
	 * RGBA Values of the clear color
	 */
	private float r, g, b, a;

	/**
	 * Width and Height Property of the GLFW Window
	 */
	private int width, height;

	private long glfwWindow = NULL;

	private static List<Level> previousLvls = new ArrayList<>();
	private static GLFWWindow win;
	private static Level currentLvl;

	/**
	 * 
	 * @param title
	 * @param width
	 * @param height
	 */
	private GLFWWindow(String title, int width, int height) {
		
		GLFWErrorCallback.createPrint(System.err).set();
		
		if(!glfwInit()) throw new IllegalStateException("Unable to initialize GLFW");
		
		glfwDefaultWindowHints();
		glfwWindowHint(GLFW_VISIBLE, GLFW_FALSE);
		
		if((glfwWindow = glfwCreateWindow(this.width = width, this.height = height, this.title = title, NULL, NULL)) == NULL) throw new IllegalStateException("Failed to create a GLFW Window");
		
		glfwSetCursorPosCallback(glfwWindow, MouseListener::mousePosCallback);
		glfwSetMouseButtonCallback(glfwWindow, MouseListener::mouseButtonCallback);
		glfwSetScrollCallback(glfwWindow, MouseListener::mouseScrollCallback);
		glfwSetKeyCallback(glfwWindow, KeyListener::keyCallback);
		
		glfwMakeContextCurrent(glfwWindow);
		glfwSwapInterval(1);
		
		GL.createCapabilities();
		
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	
	}

	/**
	 * 
	 * @return The Created GLFW Window
	 */
	public static GLFWWindow createWindow() { return createWindow("GLFW Window", 854, 480); }

	/**
	 * 
	 * @return The Created GLFW Window
	 */
	public static GLFWWindow createWindow(String title) { return createWindow(title, 854, 480); }

	/**
	 * 
	 * @return The Created GLFW Window
	 */
	public static GLFWWindow createWindow(String title, int width, int height) {
		
		if(win == null) win = new GLFWWindow(title, width, height);
		
		return win;
	
	}

	/**
	 * 
	 * @return The Created GLFW Window
	 */
	public static GLFWWindow createWindow(int width, int height) { return createWindow("GLFW Window", width, height); }

	/**
	 * 
	 * @return The Created GLFW Window
	 */
	public static GLFWWindow get() { return win; }

	public Level getCurrentLevel() { return currentLvl; }

	public Level getPreviousLevel(int index) { return previousLvls.get(index); }

	public int HEIGHT() { return height; }

	public int WIDTH() { return width; }

	/**
	 * 
	 * @param monitorIndex
	 */
	public void centerWindow(int monitorIndex) { centerWindow(glfwGetMonitors().get(monitorIndex)); }

	/**
	 * 
	 * @param monitor
	 */
	public void centerWindow(long monitor) {
		
		Monitor mon = Monitor.getMonitorDetail(monitor);
		
		glfwSetWindowPos(glfwWindow, (mon.monitorPosX() + (mon.width() - width) / 2), (mon.monitorPosY() + (mon.height() - height) / 2));
	
	}

	/**
	 * 
	 * @param monitorIndex
	 */
	public void fullscreenWindow(int monitorIndex) { fullscreenWindow(glfwGetMonitors().get(monitorIndex)); }

	/**
	 * 
	 * @param monitor
	 */
	public void fullscreenWindow(long monitor) {
		
		Monitor mon = Monitor.getMonitorDetail(monitor);
		
		glfwSetWindowMonitor(glfwWindow, monitor, mon.monitorPosX(), mon.monitorPosY(), mon.width(), mon.height(), mon.refreshRate());
	
	}

	/**
	 * Maximizes the window to the current display location of the window
	 */
	public void maximizeWindow() { glfwMaximizeWindow(glfwWindow); }

	/**
	 * Shows the window and starts the game loop
	 */
	public void run() {
		
		System.gc();
		
		glfwShowWindow(glfwWindow);
		initLoops();
	
	}

	/**
	 * Sets the specified level to be displayed and runned while the previous one will be set to a list
	 * 
	 * @param lvl The new level to be played
	 */
	public void setCurrentLevel(Level lvl) {
		
		if(currentLvl != null) previousLvls.add(previousLvls.size(), currentLvl);
		
		Collections.rotate(previousLvls, 1);
		
		currentLvl = lvl;
		currentLvl.init();
		currentLvl.start();
	
	}

	/**
	 * Changes the clear color of the OpenGL Buffer in it's RGB values. See {@code glClearColor} for more information<br/>
	 * <br/>
	 * Uses the previous old Alpha value
	 * 
	 * @param r The value of the red channel to clear the buffer
	 * @param g The value of the green channel to clear the buffer
	 * @param b The value of the blue channel to clear the buffer
	 */
	public void setClearColor(float r, float g, float b) { setClearColor(r, g, b, a); }

	/**
	 * Changes the clear color of the OpenGL Buffer in it's RGBA values. See {@code glClearColor} for more information
	 * 
	 * @param r The value of the red channel to clear the buffer
	 * @param g The value of the green channel to clear the buffer
	 * @param b The value of the blue channel to clear the buffer
	 * @param a The value of the alpha channel to clear the buffer
	 */
	public void setClearColor(float r, float g, float b, float a) {
		
		this.r = r;
		this.g = g;
		this.b = b;
		this.a = a;
	
	}
 
	/**
	 * Sets an attribute to the window. See {@link GLFW#glfwSetWindowAttrib} for more information
	 * 
	 * @param attrib The attribute name from GLFW
	 * @param value The value to set to the attribute
	 */
	public void setWindowAttribute(int attrib, int value) { glfwSetWindowAttrib(glfwWindow, attrib, value); }

	public void setWindowIcon(Image icon) { glfwSetWindowIcon(glfwWindow, icon.GLFW_IMAGE); }

	public void setWindowIcon(String iconPath) throws IOException { try(Image icon = new Image(iconPath)) { setWindowIcon(icon); } }

//	public void setWindowIcon(String pathToIcons) throws IOException {
//		
//		File iconFld = new File(pathToIcons);
//		File[] icons = iconFld.listFiles();
//		GLFWImage.Buffer iconsBuf = GLFWImage.create(icons.length);
//		
//		for(int a = 0; a < icons.length; a++) {
//			
//			if(icons[a].isFile()) {
//				
//				try(Image icon = new Image(icons[a].getAbsolutePath())) {
//					
//					iconsBuf.put(a, icon.GLFW_IMAGE);
//				
//				}
//			
//			}
//		
//		}
//		
//		glfwSetWindowIcon(glfwWindow, iconsBuf);
//	
//	}

	/**
	 * Destorys the window and it's context, and frees memory
	 */
	public void stop() {
		
		glfwFreeCallbacks(glfwWindow);
		glfwDestroyWindow(glfwWindow);
		
		glfwTerminate();
		glfwSetErrorCallback(null).free();
	
	}

	/**
	 * 
	 */
	private void initLoops() {
		
		while(!glfwWindowShouldClose(glfwWindow)) {
			
			glfwPollEvents();
			
			glClearColor(r, g, b, a);
			glClear(GL_COLOR_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
			
			if(currentLvl != null) currentLvl.update(dt);
			
			glfwSwapBuffers(glfwWindow);
			
			eTime = (float) glfwGetTime();
			dt = eTime - bTime;
			bTime = eTime;
		
		}
	
	}

}
