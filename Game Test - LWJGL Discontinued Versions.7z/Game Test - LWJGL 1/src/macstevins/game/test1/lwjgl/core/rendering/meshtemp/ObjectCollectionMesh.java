package macstevins.game.test1.lwjgl.core.rendering.meshtemp;

import java.util.*;

import org.joml.*;
import org.lwjgl.*;

import macstevins.game.test1.lwjgl.core.level.object.type.*;

public class ObjectCollectionMesh<T> extends MeshRenderer<Vector2f, T> {

	private static ArrayList<ObjectCollectionMesh<?>> instances;

	protected GameObject[] objects;
	protected int objLimit, numObjs;

	public ObjectCollectionMesh(int objLimit) {
		
		if(objLimit < 1 && objLimit > 1024) objLimit = 1024;
		objects = new GameObject[this.objLimit = objLimit];
		
		vertArr = BufferUtils.createFloatBuffer(objLimit * 4 * VERT_SIZE);
		init(genIndices());
	
	}

	public static ObjectCollectionMesh<?> create() { return create(255, 3); }

	public static ObjectCollectionMesh<?> create(int objLimit) { return create(objLimit, 3); }

	public static ObjectCollectionMesh<?> create(int objLimit, int color) {
		
		if(instances == null) instances = new ArrayList<>();
		
		if(color == 3) instances.add(new ObjectCollectionMesh<Vector3f>(objLimit));
		else if(color == 4) instances.add(new ObjectCollectionMesh<Vector4f>(objLimit));
		else throw new RuntimeException("Color \"" + color + "\" is invalid");
		
		return instances.get(instances.size() - 1);
	
	}

	public void addObjectToMesh(GameObject obj) {
		
		objects[objects.length] = obj;
		numObjs++;
		
		
	
	}

	private int[] genIndices() {
		
		int[] elem = new int[6 * objLimit];
		for(int a = 0; a < objLimit; a++) initElemIndices(elem, a);
		return elem;
	
	}

	private void initElemIndices(int[] elem, int index) {
		
		int offArrayInd = 6 * index,
			off = 4 * index;
		
		elem[offArrayInd] = off + 3;
		elem[offArrayInd + 1] = elem[offArrayInd + 4] = off + 2;
		elem[offArrayInd + 2] = elem[offArrayInd + 3] = off;
		elem[offArrayInd + 5] = off + 1;
	
	}

}
