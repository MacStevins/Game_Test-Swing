package macstevins.game.test1.lwjgl.core.level.object.component;

public interface Controllable extends Component {

	public int UP    = 1,
			   DOWN  = 2,
			   LEFT  = 3,
			   RIGHT = 4;

	public default void setKey(int key, int motion) {
		
		if(motion == UP)    Controls.UP_KEY    = key;
		if(motion == DOWN)  Controls.DOWN_KEY  = key;
		if(motion == LEFT)  Controls.LEFT_KEY  = key;
		if(motion == RIGHT) Controls.RIGHT_KEY = key;
	
	}

	@Override
	public default void start() {}

	@Override
	public default void update() {
		
//		if(KeyListener.isKeyPressed(Controls.UP_KEY)) position.y++;
//		if(KeyListener.isKeyPressed(Controls.DOWN_KEY)) position.x--;
//		if(KeyListener.isKeyPressed(Controls.LEFT_KEY)) position.y--;
//		if(KeyListener.isKeyPressed(Controls.RIGHT_KEY)) position.x++;
	
	}

	class Controls {
		
		@SuppressWarnings("unused")
		private static int UP_KEY,
						   DOWN_KEY,
						   LEFT_KEY,
						   RIGHT_KEY;
	
	}

}
