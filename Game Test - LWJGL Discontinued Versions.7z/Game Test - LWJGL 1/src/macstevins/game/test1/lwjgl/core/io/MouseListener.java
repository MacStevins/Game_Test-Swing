package macstevins.game.test1.lwjgl.core.io;

import static org.lwjgl.glfw.GLFW.*;

public class MouseListener {

	private boolean mouseButtonPressed[] = new boolean[GLFW_MOUSE_BUTTON_LAST + 1], isDragging;
	private double lastX, lastY, scrollX, scrollY, xPos, yPos;

	private static MouseListener instance;

	private MouseListener() { lastX = lastY = scrollX = scrollY = xPos = yPos = 0; }

	/**
	 * Checks if the mouse is being dragged
	 * 
	 * @return The state of the mouse being dragged
	 */
	public static boolean isDragging() { return get().isDragging; }

	/**
	 * Checks the given mouse button state
	 * 
	 * @param button The mouse button
	 * @return The state of the mouse button being pressed
	 */
	public static boolean isMouseButtonDown(int button) { return get().mouseButtonPressed[button]; }

	/**
	 * Gets the delta horizontal distance between the last recorded positiion to the current position of the mouse pointer
	 * 
	 * @return The delta horizontal distance
	 */
	public static float getDx() { return (float) (get().lastX - get().xPos); }

	/**
	 * Gets the delta vertical distance between the last recorded positiion to the current position of the mouse pointer
	 * 
	 * @return The delta vertical distance
	 */
	public static float getDy() { return (float) (get().lastY - get().yPos); }

	/**
	 * Gets the scroll amount in the horizontal axis<br/>
	 * <br/>
	 * Only works for mouses that has horizontal scrolling
	 * 
	 * @return The scroll amount in the horizontal axis
	 */
	public static float getScrollX() { return (float) get().scrollX; }

	/**
	 * Gets the scroll amount in the vertical axis
	 * 
	 * @return The scroll amount in the vertical axis
	 */
	public static float getScrollY() { return (float) get().scrollY; }

	/**
	 * Gets the horizontal position of the mouse pointer relative to the GLFW window
	 * 
	 * @return The horizontal position relative to the window
	 */
	public static float getX() { return (float) get().xPos; }

	/**
	 * Gets the vertical position of the mouse pointer relative to the GLFW window
	 * 
	 * @return The vertical position relative to the window
	 */
	public static float getY() { return (float) get().yPos; }

	/**
	 * Callback function of mouse position for GLFW
	 * 
	 * @param win The window that detected a pointer motion
	 * @param xPos The horizontal position relative to the window
	 * @param yPos The vertical position relative to the window
	 */
	public static void mousePosCallback(long win, double xPos, double yPos) {
		
		get().lastX = get().xPos;
		get().lastY = get().yPos;
		get().xPos = xPos;
		get().yPos = yPos;
		get().isDragging = get().mouseButtonPressed[0] || get().mouseButtonPressed[1] || get().mouseButtonPressed[2];
	
	}

	/**
	 * Callback function of mouse button for GLFW
	 * 
	 * @param win The window that detected a mouse button action
	 * @param but The mouse button
	 * @param act The action of the mouse button
	 * @param mods The modifiers being pressed from the keyboard
	 */
	public static void mouseButtonCallback(long win, int but, int act, int mods) {
		
		get().mouseButtonPressed[but] = (act == GLFW_PRESS) ? true : false;
		get().isDragging = (act == GLFW_PRESS) ? get().isDragging : false;
	
	}

	/**
	 * Callback function of mouse scroll for GLFW
	 * 
	 * @param win The window that detected a mouse scroll action
	 * @param xOff The horizontal offset of the scroll wheel<br/>
	 * Only works for mouses that has horizontal scrolling<br/>
	 * <br/>
	 * @param yOff The vertical offset of the scroll wheel
	 */
	public static void mouseScrollCallback(long win, double xOff, double yOff) {
		
		get().xPos = xOff;
		get().yPos = yOff;
	
	}

	/**
	 * Resets values to the last values for distance check between frames or refreshes
	 */
	public static void endFrame() {
		
		get().scrollX = get().scrollY = 0;
		get().lastX = get().xPos;
		get().lastY = get().yPos;
	
	}

	/**
	 * Create a single instance of the {@code MouseListener} class
	 * 
	 * @return The instance of the {@code MouseListener} class
	 */
	private static MouseListener get() {
		
		if(instance == null) instance = new MouseListener();
		return instance;
	
	}

}
