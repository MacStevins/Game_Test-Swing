package macstevins.game.test1.lwjgl.core.io;

import java.io.*;

public class FileUtils {

	public static String getFileExtension(String filePath) throws IOException { return getFileExtension(new File(filePath)); }

	public static String getFileExtension(File file) throws IOException {
		
		if(!file.isFile()) throw new IOException("File/Folder '" + file + "' is not a file");
		
		String fileName = file.getName();
		return fileName.substring(fileName.lastIndexOf('.') + 1).toLowerCase();
		
	}

	public static boolean checkFileExtension(String filePath, String compareExtension) throws IOException { return checkFileExtension(new File(filePath), compareExtension); }

	public static boolean checkFileExtension(File file, String compareExtension) throws IOException { return getFileExtension(file).equals(compareExtension.toLowerCase()); }

}
