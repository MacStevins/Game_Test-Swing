package macstevins.game.test1.lwjgl.core.rendering.meshtemp2;

public class ObjectCollectionMesh
//extends MeshRenderer
{

//	protected ArrayList<GameObject> objects;
//	protected boolean isFull;
//	protected int objLimit;
//
//	public ObjectCollectionMesh() { this(255, 3); }
//
//	public ObjectCollectionMesh(int objLimit) { this(objLimit, 3); }
//
//	public ObjectCollectionMesh(int objLimit, int color) {
//		
//		if(objLimit < 1 && objLimit > 1024) objLimit = 1024;
//		objects = new ArrayList<>();
//		
//		COL_SIZE = color;
//		resetValues();
//		
//		vertArr = BufferUtils.createFloatBuffer(objLimit * VERT_SIZE);
//		init(genIndices());
//	
//	}
//
//	public void addObjectToMesh(GameObject obj) {
//		
//		objects.add(obj);
//		
//		
//		
//		if(objects.size() == objLimit) isFull = true;
//	
//	}
//
//	private int[] genIndices() {
//		
//		int[] elems = new int[6 * objLimit];
//		for(int a = 0; a < objLimit; a++) initElemIndices(elems, a);
//		return elems;
//	
//	}
//
//	private void initElemIndices(int[] elems, int index) {
//		
//		int offArrayInd = 6 * index,
//			off = 4 * index;
//		
//		elems[offArrayInd] = off + 3;
//		elems[offArrayInd + 1] = elems[offArrayInd + 4] = off + 2;
//		elems[offArrayInd + 2] = elems[offArrayInd + 3] = off;
//		elems[offArrayInd + 5] = off + 1;
//	
//	}

}
