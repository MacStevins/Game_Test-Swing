package macstevins.game.test1.lwjgl.core.io;

import static org.lwjgl.glfw.GLFW.*;

public class KeyListener {

	private static KeyListener instance;
	private boolean keyPressed[] = new boolean[GLFW_KEY_LAST + 2];

	/**
	 * Checks the given keyboard keys state
	 * 
	 * @param code The keyboard key code
	 * @return The state of the key being pressed
	 */
	public static boolean isKeyPressed(int code) { return get().keyPressed[code]; }

	/**
	 * Callback function of keyboard keys for GLFW
	 * 
	 * @param win The window that detected a key action
	 * @param key The keyboard key code
	 * @param scode The platform-specific scancode
	 * @param act The action key
	 * @param mods The modifier keys
	 */
	public static void keyCallback(long win, int key, int scode, int act, int mods) {
		
		get().keyPressed[key] = (act == GLFW_RELEASE) ? false : true;
	
	}

	/**
	 * Create a single instance of the {@code KeyListener} class
	 * 
	 * @return The instance of the {@code KeyListener} class
	 */
	private static KeyListener get() {
		
		if(instance == null) instance = new KeyListener();
		return instance;
	
	}

}
