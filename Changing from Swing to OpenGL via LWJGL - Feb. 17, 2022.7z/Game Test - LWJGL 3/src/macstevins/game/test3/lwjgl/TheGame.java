package macstevins.game.test3.lwjgl;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;

import org.lwjgl.glfw.*;
import org.lwjgl.opengl.*;

public class TheGame {

	private static long glfwWindow;

	public TheGame() {
		
		GLFWErrorCallback.createPrint(System.err).set();
		if(!glfwInit()) throw new IllegalStateException("GLFW Initialization failed.");
		
		glfwDefaultWindowHints();
		glfwWindowHint(GLFW_VISIBLE, GL_FALSE);
		
		glfwWindow = glfwCreateWindow(500, 500, "GLFW Window", 0, 0);
		
		glfwMakeContextCurrent(glfwWindow);
		
		GL.createCapabilities();
		GLUtil.setupDebugMessageCallback(System.err);
		glfwShowWindow(glfwWindow);
		
		System.gc();
		
		while(!glfwWindowShouldClose(glfwWindow)) {
			
			glfwPollEvents();
			glClear(GL_COLOR_BUFFER_BIT);
			
			glClearColor((238f / 255), (238f / 255), (238f / 255), 1);
			
			glBegin(GL_QUADS);
				glColor3f(0, 0, 0);
				glVertex2f(-.05f,  .05f);
				glVertex2f( .05f,  .05f);
				glVertex2f( .05f, -.05f);
				glVertex2f(-.05f, -.05f);
			glEnd();
			
			glfwSwapBuffers(glfwWindow);
		
		}
		
		glfwTerminate();
	
	}

}
