package macstevins.game.test1.core.window;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import macstevins.game.test1.core.io.Settings;

public class SettingsDialog extends JDialog {

	private static final long serialVersionUID = 6025590532086173270L;

	public SettingsDialog() {
		
		getRootPane().setPreferredSize(new Dimension(305, 85));
		setLayout(new FlowLayout(FlowLayout.CENTER, 15, 15));
		setResizable(false);
		setDefaultCloseOperation(0);
		setTitle("Framerate: " + Settings.fps);
		
		JTextField tfKeys  = new JTextField(10);
		JSlider sldrFPS = new JSlider(0, 0, 48, Settings.fps / 5);
		JButton btnChng = new JButton("Change Keys");
		
		sldrFPS.addChangeListener(new ChangeListener() { @Override public void stateChanged(ChangeEvent e) { setTitle("Framerate: " + (Settings.fps = ((JSlider) e.getSource()).getValue() * 5)); } });
		
		btnChng.addActionListener(new ActionListener() { @Override public void actionPerformed(ActionEvent e) { new KeyChangeDialog("Change Keys", ModalityType.APPLICATION_MODAL); } });
		btnChng.setPreferredSize(new Dimension(110, 25));
		
		tfKeys.setEditable(false);
		
		add(new JLabel("Framerate:"));
		add(sldrFPS);
		add(btnChng);
//		add(tfKeys);
		
		pack();
		setLocationRelativeTo(null);
		setLocation(getX() + 450, getY());
		setVisible(true);
	
	}

}
