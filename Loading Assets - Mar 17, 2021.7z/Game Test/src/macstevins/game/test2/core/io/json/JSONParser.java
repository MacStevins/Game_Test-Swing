package macstevins.game.test2.core.io.json;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;

public class JSONParser {

	public void parseJSON(File file) throws FileNotFoundException { parseJSON(new BufferedReader(new FileReader(file))); }

	public void parseJSON(Reader read) {
		
		
	
	}

}
