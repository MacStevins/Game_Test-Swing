package macstevins.game.test2.core.io;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class AssetLoader {

	private static AssetLoader inst;
	private static Path assetDir;
	private static Path tmpDir;

	private AssetLoader(String packPath) {
			
		try {
			
			File runDir = new File(getClass().getProtectionDomain().getCodeSource().getLocation().toURI().getPath());
			
			if(runDir.isDirectory()) tmpDir = runDir.toPath();
			else {
				
				FileUtil.extractZip(runDir, (tmpDir = Files.createTempDirectory(packPath + ".asset.")).toFile(), "assets");
				Runtime.getRuntime().addShutdownHook(new Thread() { @Override public synchronized void start() { FileUtil.deleteDir(tmpDir.toFile()); } });
			
			}
			
			assetDir = Paths.get(tmpDir.toString(), "assets", packPath.replace(".", File.separator));
		
		}
		catch(Exception e) { e.printStackTrace(); }
	
	}

	public static AssetLoader createInstance(String packPath) { return (inst == null) ? inst = new AssetLoader(packPath) : inst; }

	public static File getAsset(String type, String name) {
		
		for(File f : assetDir.toFile().listFiles()) if(f.getName().equals(type)) for(File fa : f.listFiles()) if(fa.getName().equals(name)) return fa;
		
		return null;
	
	}

}
