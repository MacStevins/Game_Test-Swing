package macstevins.game.test2.core.io;

@Deprecated
public class LevelParser {

	public LevelParser() {
		
		
	
	}

}
