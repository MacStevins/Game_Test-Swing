package macstevins.game.test2.core.window;

import java.awt.Color;

import javax.swing.JPanel;

public class Layer extends JPanel {

	private static final long serialVersionUID = 4604585660651855838L;

	public Layer() { setBackground(new Color(0, 0, 0, 0)); }

}
