package macstevins.game.test2.core.window;

import java.awt.Color;
import java.awt.Graphics;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import macstevins.game.test2.core.io.Fonts;
import macstevins.game.test2.core.io.KeyHandler.WindowHandler;
import macstevins.game.test2.core.world.World;

public class Game extends Window {

	private String fpsDis = "FPS: 0 / 0, Frame Time: 0.0 ms";
	private double time = System.nanoTime() / 1000000000.0, time2, secPass = 0, frmTm;
	private int frames = 0;

	private static final long serialVersionUID = 455940033047564854L;

	protected World wrld = new World(this);

	public void drawFps() {
		
		Layer lyrFps = new Layer() {
		
			private static final long serialVersionUID = 6753664693232713986L;
		
			@Override
			protected void paintComponent(Graphics g) {
				
				super.paintComponent(g);
				
				g.setFont(Fonts.getFont("Roboto"));
				g.setColor(new Color(175, 175, 175, 128));
				g.fillRect(0, 0, g.getFontMetrics().stringWidth(fpsDis) + 12, 20);
				
				g.setColor(Color.black);
				g.drawString(fpsDis, 6, 15);
			
			}
		
		};
		
		lyrFps.setBounds(10, 10, getPanelSize().width, 20);
		add(lyrFps, 0);
	
	}

	private void loop() {
		
		((ScheduledExecutorService) Executors.newSingleThreadScheduledExecutor()).scheduleAtFixedRate(new Runnable() {
		
			@Override
			public void run() {
				
				if(WindowHandler.hasLostFocus) return;
				wrld.update();
			
			}
		
		}, 0, 100000, TimeUnit.NANOSECONDS);
		
		((ScheduledExecutorService) Executors.newSingleThreadScheduledExecutor()).scheduleAtFixedRate(new Runnable() {
		
			@Override
			public void run() {
				
				if(WindowHandler.hasLostFocus) return;
				repaint();
			
			}
		
		}, 0, 16666666, TimeUnit.NANOSECONDS);
	
	}

	@Override
	public void init() {
		
		add(wrld);
		wrld.init();
		super.init();
		
		loop();
	
	}

	@Override
	public void paint(Graphics g) {
		
		secPass += (time2 = System.nanoTime() / 1000000000.0) - time;
		
		super.paint(g);
		
		if(secPass >= 1) {
			
			fpsDis = "FPS: " + frames + " / " + (int) (1000 / frmTm) + ", Frame Time: " + (Math.round(frmTm * 100.0) / 100.0) + " ms";
			secPass = 0;
			frames = 0;
		
		}
		frmTm = ((time2 * 1000) - (time * 1000));
		frames++;
		time = time2;
	
	}

	@Override public void run() { throw new IllegalStateException("Window and Game has not initialized, please contact the developer."); }

}
