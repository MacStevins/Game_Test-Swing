package macstevins.game.test2.core.window;

import java.awt.Dimension;
import java.awt.Font;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import macstevins.game.test2.core.io.AssetLoader;
import macstevins.game.test2.core.io.Fonts;

public class ExceptionWindow extends Window {

	private static final long serialVersionUID = -6813844233743107388L;

	private ByteArrayOutputStream baos = new ByteArrayOutputStream();
	private JTextArea taExc = new JTextArea();
	private Window win;

	public ExceptionWindow(Window win) { this.win = win; }

	private void loop() {
		
		ScheduledExecutorService sec = Executors.newSingleThreadScheduledExecutor();
		sec.scheduleAtFixedRate(new Runnable() {
		
			@Override
			public void run() {
				
				String errLog = new String(baos.toByteArray());
				
				if(!errLog.isEmpty()) {
					
					win.dispose();
					
					taExc.setText(errLog);
					init(true);
					
					System.gc();
					
					sec.shutdown();
				
				}
			
			}
		
		}, 0, 100, TimeUnit.MILLISECONDS);
	
	}

	@Override
	public void init() {
		
		try {
			
			loop();
			
			Font font = Fonts.createFont(Font.TRUETYPE_FONT, AssetLoader.getAsset("fonts", "Roboto-Regular.ttf"));
			JLabel lblMsg = new JLabel("<html><style>h2, p{color:black}</style><h2>Oh no! An error has occured and the app crashed.</h2><p>Here's the crash log java provided:</p></html>");
			JScrollPane spExc = new JScrollPane(taExc);
			
			lblMsg.setFont(font);
			lblMsg.setBounds(27, 6, 413, 57);
			
			taExc.setFont(font);
			taExc.setEditable(false);
			spExc.setBounds(15, 73, 720, 265);
			
			setSize(new Dimension(750, 500));
			setTitle("Exception Handler");
			setResizable(false);
			
			add(lblMsg);
			add(spExc);
			System.setErr(new PrintStream(baos, true));
			System.gc();
		
		}
		catch(Exception e) { e.printStackTrace(); }
	
	}

	@Override public void run() { init(); }

}
