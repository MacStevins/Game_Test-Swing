package macstevins.game.test2.core.world;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;

public class Object {

	protected Color clr = Color.black;
	protected Point prevPos;
	protected Rectangle rect;
	protected String name;

	public Object(Color clr, Dimension size, Point initPos) { this(clr, size, initPos, "obj"); }

	public Object(Color clr, Dimension size, Point initPos, String name) {
		
		this.clr = clr;
		this.name = name;
		rect = new Rectangle(initPos, size);
	
	}

	public Object setRectBounds(Rectangle rect) {
		
		this.rect = rect;
		return this;
	
	}

	public void update() {}

}
