package macstevins.game.test2;

import macstevins.game.test2.core.Initializer;

public class Main {

	public static void main(String[] args) throws Exception {
		
		//Uncomment below for Power Saving Mode on Windows
		System.setProperty("sun.java2d.opengl", "true");
		
		System.out.println("Hello, World!\n");
		new Initializer(new TheGame(), Main.class.getPackage().getName());
	
	}

}
